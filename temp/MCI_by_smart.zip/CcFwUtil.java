package chs.ccg.dp.co.cmmn.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.inswave.elfw.ElConfig;
import com.inswave.elfw.core.CommVO;
import com.inswave.elfw.core.ElHeader;
import com.inswave.elfw.databind.DefaultPropertyNamingStrategy;
import com.inswave.elfw.log.AppLog;
import com.inswave.elfw.meta.ElSysPropManager;
import com.inswave.elfw.util.CommUtil;
import com.inswave.elfw.util.ElBeanUtils;
import com.inswave.elfw.util.PropUtil;
import com.inswave.elfw.view.ElMappingJacksonObjectMapper;

public class CcFwUtil {

	/**
	 * getFileProp	elfw.properties에서 값을 얻어옴 - 정상동작 확인되면 PropUtil.getMessage 로 바꿀 것
	 * @param propGrp
	 * @param propKey
	 * @return
	 */
	public static String propUtil_getMessage(String propKey) {
		String configValue = PropUtil.getMessage(propKey);
//		if(AppLog.isDebugEnabled()) {
//			AppLog.debug("getFileProp('"+propKey+"')=["+configValue+"]");
//		}
		return configValue;
	}	

	/**
	 * getElProp	서버모드(DEV/TST/RUN)를 고려한 프로퍼티 값 얻기, propKey.서버모드 가 있으면 우선 얻어옴, 없으면 propKey에 정의된 값을 얻어옴, null은 ""로 변환되어 리턴
	 * @param propGrp
	 * @param propKey
	 * @return
	 */
	public static String getElProp(String propGrp, String propKey) {
		return getElProp(propGrp, propKey, "");
	}
		
	/**
	 * getElProp	서버모드(DEV/TST/RUN)를 고려한 프로퍼티 값 얻기, propKey.서버모드 가 있으면 우선 얻어옴, 없으면 propKey에 정의된 값을 얻어옴, null은 defaultVal로 변환되어 리턴
	 * @param propGrp
	 * @param propKey
	 * @return
	 */
	public static String getElProp(String propGrp, String propKey, String defaultVal) {
		ElSysPropManager elspm = ElSysPropManager.getInstance();
		// 서버모드에 따른 값을 먼저 얻어 본후 없으면 공통 값 사용
		String propKeyReal =  propKey+"."+ElConfig.getServerMode();	// PROPKEY.DEV
		String configValue = elspm.getPropVoValue(propGrp, propKeyReal);
		if(configValue==null) {
			propKeyReal = propKey;									// PROPKEY
			configValue = elspm.getPropVoValue(propGrp, propKeyReal);
		}
		
		if(configValue==null) {
			configValue = defaultVal;
		} else {
			configValue = com.inswave.elfw.util.StringUtil.fromHtml(configValue).trim();
		}

//		if(AppLog.isDebugEnabled()) {
//			AppLog.debug("getElProp('"+propGrp+"','"+propKey+"')["+propKeyReal+"]=["+configValue+"]");
//		}
		return configValue;
	}
	
	/**
	 * 내부용 : 반드시 getObjectMapper()를 사용할 것, 직접 사용 금지
	 */
	private static ElMappingJacksonObjectMapper elJacksonOm = null;
	
	/**
	 * getObjectMapper 필요시 초기화후 ElMappingJacksonObjectMapper를 얻어냄
	 * @return
	 */
	private static synchronized ElMappingJacksonObjectMapper getObjectMapper() {
		if (elJacksonOm == null) {
			elJacksonOm = new ElMappingJacksonObjectMapper();
			elJacksonOm.setExcludeNullYn("N");
			elJacksonOm.setExcludeNames(new HashMap());			
			elJacksonOm.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			elJacksonOm.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
			elJacksonOm.setPropertyNamingStrategy(new DefaultPropertyNamingStrategy());
		}
		return elJacksonOm;
	}


	public static JsonNode readTree(String data) throws Exception {
		return getObjectMapper().readTree(data);
	}

	/**
	 * toJson Object를 JsonString으로 변환
	 * @param obj
	 * @return
	 * @throws JsonProcessingException
	 */
	public static String toJsonString(Object obj) throws Exception {
		return toJsonString(obj, false);
	}

	/**
	 * toJson Object를 JsonString으로 변환, useBean이 true인 경우 bean을 사용하므로 excludeNames는 변환에서 제외됨
	 * @param obj
	 * @return
	 * @throws JsonProcessingException
	 */
	public static String toJsonString(Object obj, boolean useBean) throws Exception {
		ElHeader eh = null;
		long startTime = 0;
		try{
			if (obj instanceof ElHeader) {
				eh = ((ElHeader)obj);
				startTime = eh.getStartTime();		// 개인정보 오탐 방지
				eh.setStartTime(0);
			}
			if (useBean) {
				ElMappingJacksonObjectMapper bean = (ElMappingJacksonObjectMapper)ElBeanUtils.getBean("jsonMapper");
				bean.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
				return bean.writeValueAsString(obj);
			}
			return getObjectMapper().writeValueAsString(obj);
		} finally {
			if (eh != null) eh.setStartTime(startTime);
		}
	}
	
	/**
	 * fromJson Object를 JsonString으로 변환, Vo인 경우 excludeNames는 변환에서 제외됨
	 * @param obj
	 * @return
	 * @throws JsonProcessingException
	 */
	public static <T> T fromJsonString(String str, Class<T> toValueType) throws Exception {
		return getObjectMapper().readValue(str, toValueType);
	}
	
	public static <T> T fromXmlString(InputStream is, Class<T> toValueType) throws Exception {
		return getObjectMapper().readValue(is, toValueType);
	}

	/**
	 * convertValue Object를 toValueType객체로 변환, Vo인 경우 excludeNames는 변환에서 제외됨
	 * @param obj
	 * @return
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws JsonProcessingException
	 */
	public static <T> T convertValue(Object from, Class<T> toValueType) throws JsonParseException, JsonMappingException, IOException {
		if (from instanceof JsonParser) {
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			return objectMapper.readValue((JsonParser)from, toValueType);
		}
		return getObjectMapper().convertValue(from, toValueType);
	}
	
	/**
	 * sendPostUrl http post 요청하고 응답 받아옴
	 * @param stUrl
	 * @param postData
	 * @param timeoutMs	시간제한 0보다 크면 적용됨
	 * @return
	 * @throws Exception
	 */
	public static byte[] sendPostUrl(String stUrl, byte[] postData,int timeoutMs) throws Exception {
		HttpURLConnection conn = null;
		OutputStream out = null;
		InputStream is = null;
		ByteArrayOutputStream byteArrayOutputStream = null;
		int readCount = 0;
		byte[] rtnArray = null;
		byte[] buff = new byte[1024];
		try
		{
		    // https 사설인증서허용 
		    try {
				CommUtil.ignoreSsl();
			} catch (IOException e) {
				AppLog.debug("BeIgnore", e);
			} catch (Exception e) {
				AppLog.debug("BeIgnore", e);
			}
	
			URL url = new URL(stUrl);

			conn = (HttpURLConnection)url.openConnection();
			
			if (timeoutMs > 0) {
				conn.setConnectTimeout(timeoutMs);
				conn.setReadTimeout(timeoutMs);
			}
			conn.setDoOutput(true);
			conn.setUseCaches(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");// application/x-www-form-urlencoded");
			conn.setRequestProperty("Content-Length", Integer.toString(postData.length));
			// conn.setRequestProperty("Cookie", "lang=ko;bodyYn=Y");	// 아래 두개로 대체가능
			conn.setRequestProperty("Proworks-Body","Y");  // HTTP Body로 JSON 객체를 전달하기 위한 여부
			conn.setRequestProperty("Proworks-Lang","ko");  // 다국어 처리를 위한 언어 설정 (미설정 시 프레임워크에서 ko 세팅)

			out = conn.getOutputStream();

			out.write(postData);

			is = conn.getInputStream();
			byteArrayOutputStream = new ByteArrayOutputStream();
			while ((readCount = is.read(buff)) != -1) {
				byteArrayOutputStream.write(buff, 0, readCount);
			}
			byteArrayOutputStream.flush();
			rtnArray = byteArrayOutputStream.toByteArray();
			return rtnArray;
		} finally {
			try { if (out != null) out.close(); } catch (IOException e) { AppLog.debug("BeIgnore"); } catch (Exception e) { AppLog.debug("BeIgnore"); }	
			try { if (is != null) is.close(); } catch (IOException e) { AppLog.debug("BeIgnore"); } catch (Exception e) { AppLog.debug("BeIgnore"); }	
			try { if (conn != null) conn.disconnect(); } catch (NullPointerException e) { AppLog.debug("BeIgnore"); } catch (Exception e) { AppLog.debug("BeIgnore"); }	
		}
	}
	
	/**
	 * initializeMembers CommVo의 멤버변수중 Vo와 List가 null이면 빈객체를 만들어서 채워준다.
	 * @param inVo
	 * @throws Exception
	 */
	public static void initializeMembers(CommVO inVo) throws Exception {
		initializeMembers(inVo,false);
	}

	/**
	 * initializeMembers CommVo의 멤버변수가 null이면 빈객체를 만들어서 채워준다. withObject가 false인 경우 Vo와 List만 채워준다. true인 경우 거의 모든 객체를 생성해준다.
	 * @param inVo
	 * @param withObject
	 * @throws Exception
	 */
	public static void initializeMembers(CommVO inVo, boolean withObject) throws Exception {
		for(Field field : inVo.getClass().getDeclaredFields()) {
			Class<?> type = field.getType();
			// System.err.println(field.getName()+" "+ type);
			if (CommVO.class.isAssignableFrom(type)) {
				field.setAccessible(true);
				Object vo = field.get(inVo);
				if (vo == null) {
					vo = type.newInstance();
					field.set(inVo, vo);
					initializeMembers((CommVO)vo, withObject);
				} else if (withObject) {
					initializeMembers((CommVO)vo, withObject);
				}				
			} else if (List.class.isAssignableFrom(type)) {
				field.setAccessible(true);
				List list = (List)field.get(inVo);
				if (list == null) {
					list = new ArrayList();
					field.set(inVo, list);
				} else if (withObject) {
					for(Object item : list) initializeMembers((CommVO)item, withObject);
				}
			} else if (withObject) {
				// proworks Vo 표준 멤버가 아니면 무시 - byte[],Map,MultipartFile은 Vo에디터에서 선택은 가능하지만 서비스 i/o 용 데이터타입으로는 비표준이므로 가능하면 사용하지말자(쓸수는 있음)
				if (type.isArray()) {	
				} else if (MultipartFile.class.isAssignableFrom(type)) {	// proworks 표준 Vo 멤버가 아니므로 무시 
				} else if (Map.class.isAssignableFrom(type)) {	// proworks 표준 Vo 멤버가 아니므로 무시 
					
				} else if (String.class.isAssignableFrom(type)) {	// String 처리
					field.setAccessible(true);
					if (field.get(inVo) == null) {
						try {
							field.set(inVo, new String("")); 
						} catch(NullPointerException e) {
							AppLog.debug("BeIgnore");
						} catch(Exception e) {
							AppLog.debug("BeIgnore");
							//System.err.println(field.getName()+" "+type+" "+e.getClass().getSimpleName());
						}
					}
				} else if (Object.class.isAssignableFrom(type)) {	// BogDecimal,... 등 처리
					field.setAccessible(true);
					if (field.get(inVo) == null) {
						try {
							field.set(inVo, (type.newInstance())); 
						} catch(NullPointerException e) {
							AppLog.debug("BeIgnore");
						} catch(Exception e) {
							AppLog.debug("BeIgnore");
							//System.err.println(field.getName()+" "+type+" "+e.getClass().getSimpleName());
						}
					}
				}
			}			
		}		
	}
	
	// reflect를 사용하여 static method call
	public static Object invoke(Class cls, String method) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		return invoke(cls, null, method, null, null);
	}

	public static Object invoke(Class cls, String method, Object[] params) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		return invoke(cls, null, method, params, null);
	}

	public static Object invoke(Class cls, String method, Object[] params, Class[] paramTypes)
			throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		return invoke(cls, null, method, params, paramTypes);
	}

	// reflect를 사용하여 object method call
	public static Object invoke(Object obj, String method) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		return invoke(obj.getClass(), obj, method, null, null);
	}

	public static Object invoke(Object obj, String method, Object[] params) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		return invoke(obj.getClass(), obj, method, params, null);
	}

	public static Object invoke(Object obj, String method, Object[] params, Class[] paramTypes)
			throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		return invoke(obj.getClass(), obj, method, params, paramTypes);
	}

	private static Object invoke(Class cls, Object obj, String method, Object[] params, Class[] paramTypes)
			throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		if (params == null) {
			params = new Object[0];
		}
		if (paramTypes == null) {
			paramTypes = new Class[params.length];
			for(int i=0; i<params.length; i++) paramTypes[i] = params[i].getClass();
		}
		Method svcMethod = cls.getMethod(method, paramTypes);
		return svcMethod.invoke(obj, params);
	}
}
