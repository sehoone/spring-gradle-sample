package chs.ccg.dp.co.cmmn.util;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import com.inswave.elfw.core.CommVO;
import com.inswave.elfw.exception.UserException;
import com.inswave.elfw.log.AppLog;
import com.inswave.elfw.util.CommUtil;

import chs.ccg.dp.co.cache.CommConfigCacheManager;
import chs.ccg.dp.co.cmmn.CommUserHeader;
import chs.ccg.dp.co.dbmsg.CommMsgManager;
import chs.ccg.dp.co.dbmsg.CommMsgVo;
import chs.ccg.dp.co.mci.MciChannelConst;
import chs.ccg.dp.co.mci.MciUtil;
import chs.ccg.dp.co.mci.vo.MciCommHeaderVo;
import chs.ccg.dp.co.mci.vo.MciCommMsgVo;

public class DpMciUtil {

	/**
	 * MCI채널에 전문 송신하고 응답받기(디지털플랫폼) 
	 * @param channel
	 * @param userHeader
	 * @param inVo
	 * @param outVo
	 * @param timeoutMs	시간제한 0보다 크면 적용됨
	 * @return
	 * @throws Exception 
	 *
	 * code Insure 결과 적용 : JAVA.STD.MOSPA.202_프로그램은 프로그램 주석으로 시작해야 한다. 
	 */
	
	/*private static HttpServletRequest servletRequest;*/

	public static <T> T mciCallSerivce(CommVO inVo, Class<T> outClass, String itrfId, String rcvSvcId, String inqrTraTypeCd) throws Exception {
        if(DpStringUtil.isEmpty(itrfId)) {
        	throw new UserException("CDP00028", new String[]{"인터페이스ID "});
        }
        
        if(DpStringUtil.isEmpty(rcvSvcId)) {
        	throw new UserException("CDP00028", new String[]{"서비스ID "});
        }
        
        if(DpStringUtil.isEmpty(inqrTraTypeCd)) {
        	throw new UserException("CDP00028", new String[]{"조회거래유형코드 "});
        }
        
        MciChannelConst channel = null;
        
        /*
        // TODO : (임시) 퇴직연금일때 개발계호출로 처리, // 환경유형코드 : R:REAL(RUN), T:TEST(TST), D: 개발(DEV)
        if(rcvSvcId.indexOf("ONRIA") >= 0 && !ElConfig.getServerMode().substring(0, 1).equals("R")) {
        	channel = MciChannelConst.NL_CDP_DEV;
        }
        */
        
        return send(inVo,outClass,itrfId,rcvSvcId,inqrTraTypeCd,channel,DpDateUtil.getCurrentDate("yyyyMMdd"));
	}

	public static <T> T mciCallSerivce(CommVO inVo, Class<T> outClass, String itrfId, String rcvSvcId, String inqrTraTypeCd, MciChannelConst channel) throws Exception {
        if(DpStringUtil.isEmpty(itrfId)) {
        	throw new UserException("CDP00028", new String[]{"인터페이스ID "});
        }
        
        if(DpStringUtil.isEmpty(rcvSvcId)) {
        	throw new UserException("CDP00028", new String[]{"서비스ID "});
        }
        
        if(DpStringUtil.isEmpty(inqrTraTypeCd)) {
        	throw new UserException("CDP00028", new String[]{"조회거래유형코드 "});
        }
        
       return send(inVo,outClass,itrfId,rcvSvcId,inqrTraTypeCd,channel,DpDateUtil.getCurrentDate("yyyyMMdd"));
	}

	public static <T> T mciCallSerivce(CommVO inVo, Class<T> outClass, String itrfId, String rcvSvcId, String inqrTraTypeCd, String strYmd) throws Exception {
        if(DpStringUtil.isEmpty(itrfId)) {
        	throw new UserException("CDP00028", new String[]{"인터페이스ID "});
        }
        
        if(DpStringUtil.isEmpty(rcvSvcId)) {
        	throw new UserException("CDP00028", new String[]{"서비스ID "});
        }
        
        if(DpStringUtil.isEmpty(inqrTraTypeCd)) {
        	throw new UserException("CDP00028", new String[]{"조회거래유형코드 "});
        }
        
        MciChannelConst channel = null;
        
        /*
        // TODO : (임시) 퇴직연금일때 개발계호출로 처리, // 환경유형코드 : R:REAL(RUN), T:TEST(TST), D: 개발(DEV)
        if(rcvSvcId.indexOf("ONRIA") >= 0 && !ElConfig.getServerMode().substring(0, 1).equals("R")) {
        	channel = MciChannelConst.NL_CDP_DEV;
        }
        */
        
        return send(inVo,outClass,itrfId,rcvSvcId,inqrTraTypeCd,channel,strYmd);
	}
	
	private static <T> T send(CommVO inVo, Class<T> outClass, String itrfId, String rcvSvcId, String inqrTraTypeCd, MciChannelConst channel, String strYmd) throws Exception {
	
		MciCommHeaderVo tgrmCmnnhddvValu = new MciCommHeaderVo();
		
		CcFwUtil.initializeMembers(tgrmCmnnhddvValu, true);
		
		Method getHeaderVo = inVo.getClass().getMethod("getTgrmCmnnhddvValu", new Class[0]);
		MciCommHeaderVo getHeader = (MciCommHeaderVo) getHeaderVo.invoke(inVo, new Object[0]);
		CommUtil.mergeVo(tgrmCmnnhddvValu, getHeader);
	
		// 헤더필수값 설정 후 inVo에 입력
		tgrmCmnnhddvValu.setItrfId(itrfId);
		tgrmCmnnhddvValu.setRcvSvcId(rcvSvcId);
		
		//CRM테스트 임시 로직
		if(channel != null){
			tgrmCmnnhddvValu.setEnvrTypeCd("T");
		}
		//CRM테스트 임시 로직
		
		//tgrmCmnnhddvValu.setEnvrTypeCd(ElConfig.getServerMode().substring(0, 1));		// 환경유형코드 : R:REAL(RUN), T:TEST(TST), D: 개발(DEV)
		tgrmCmnnhddvValu.setInqrTraTypeCd(inqrTraTypeCd);		// 조회거래유형코드 등록(C), 조회(R), 변경(U), 삭제(D), 인쇄(P), 다운로드(E) 
		tgrmCmnnhddvValu.setStrYmd(strYmd);
	
		// v1.05: 어플리케이션상세업무코드 - 고객채널 업무상세구분코드 3째자리 일련번호 규칙 : 앱(0), PC(1), 모바일웹(2)
		/*			홈페이지(PC)		DH1
					홈페이지(모바일웹)	DH2
					디지털창구(PC)		DA1
					디지털창구(모바일웹)	DA2
					디지털보험(PC)		DI1
					디지털보험(모바일웹)	DI2
					디지털플랫폼앱		DA0
		*/
		CommUserHeader userHeader = CcContextUtil.getUserHeader();
		String appliDtptDutjCd = DpStringUtil.nvl(userHeader.getAppliDtptDutjCd(), "");
		AppLog.debug("appliDtptDutjCd : "+appliDtptDutjCd);
		
		/*
		// TODO : userHeader에  appliDtptDutjCd 값이 아직까지는 정상적으로 처리안됨
		if("".equals(appliDtptDutjCd)) {
			servletRequest = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
			if(servletRequest.getRequestURI().indexOf("/da/") >= 0 ) {
				appliDtptDutjCd = "DA2";
				userHeader.setAppliDtptDutjCd("DA2");
				ControllerContextUtil.setUserHeader(userHeader);
			}
		}
		*/
	
			
		tgrmCmnnhddvValu.setAppliDtptDutjCd(appliDtptDutjCd);
		if (DpStringUtil.isEmpty(tgrmCmnnhddvValu.getUserId())) {
			tgrmCmnnhddvValu.setUserId("99999999");		// 신한생명
		}
		
		// 디지털창구(모바일웹) - DA2, 디지털플랫폼앱 - DA0
		// 디지털창구(PC) - DA1	
		if("DA2".equals(appliDtptDutjCd) || "DA0".equals(appliDtptDutjCd)) {
			if (DpStringUtil.isEmpty(tgrmCmnnhddvValu.getDrtmCd())) {
				tgrmCmnnhddvValu.setDrtmCd("0995145");		// 본사-스마트창구
			}

//			// ONPAB1340(지급처리등록), ONPAD1100(개인By보험계약대출지급처리등록), ONFNC1230(즉시이체처리등록), ONPAD0460(통합보험계약대출수납처리등록), ONFNB1870(대출금액지급저장) 호출 시 헤더값 '경리조직번호' 설정
//			if("ONPAB1340".equals(rcvSvcId) || "ONPAD1100".equals(rcvSvcId) || "ONFNC1230".equals(rcvSvcId) || "ONPAD0460".equals(rcvSvcId) || "ONFNB1870".equals(rcvSvcId) ){
//				tgrmCmnnhddvValu.setAcntOgnzNo("0995145");
//			}
		} else if("DA1".equals(appliDtptDutjCd)) {
			if (DpStringUtil.isEmpty(tgrmCmnnhddvValu.getDrtmCd())) {
				tgrmCmnnhddvValu.setDrtmCd("0995350");		// 본사-사이버창구
			}

//			// ONPAB1340(지급처리등록), ONPAD1100(개인By보험계약대출지급처리등록), ONFNC1230(즉시이체처리등록), ONPAD0460(통합보험계약대출수납처리등록), ONFNB1870(대출금액지급저장) 호출 시 헤더값 '경리조직번호' 설정
//			if("ONPAB1340".equals(rcvSvcId) || "ONPAD1100".equals(rcvSvcId) || "ONFNC1230".equals(rcvSvcId) || "ONPAD0460".equals(rcvSvcId) || "ONFNB1870".equals(rcvSvcId) ){
//				tgrmCmnnhddvValu.setAcntOgnzNo("0995350");
//			}


		// DI1 : 디지털보험 PC || DI2 : 디지털보험 MOBILE WEB || DI0 : 디지털보험 APP
		} else if("DI1".equals(appliDtptDutjCd) || "DI2".equals(appliDtptDutjCd) || "DI0".equals(appliDtptDutjCd)){
			if (DpStringUtil.isEmpty(tgrmCmnnhddvValu.getDrtmCd())) {
				tgrmCmnnhddvValu.setDrtmCd("0995350");
			}
			
			// 청약서발행입금등록(코드 13) 처리 시 
			List<String> sucoServiceId = Arrays.asList("ONNBA1560", "ONKCB0016","ONNBA0430", "ONNBC0320");
			// 해피콜 대상 조회 / 스크립트조회 / 결과 저장 / 스크립트 저장
			List<String> happyCallServiceId = Arrays.asList("ONNBC0320", "ONNBC0140", "ONNBC0330");
			if (sucoServiceId.contains(rcvSvcId) || happyCallServiceId.contains(rcvSvcId)) {
				tgrmCmnnhddvValu.setDrtmCd("0911000");	// 조직
				tgrmCmnnhddvValu.setUserId("99999971");	// 인사 > 신한생명
				
	//			tgrmCmnnhddvValu.setBsduCd("094");	// 영업직책코드 > FC
	//			tgrmCmnnhddvValu.setBsquCd("02");	// 영업자격코드 > 표준
				
				tgrmCmnnhddvValu.setOgnzAsrtCd("12");	// 조직분류 > 스마트인터넷
				tgrmCmnnhddvValu.setOgnzLeveCd("3");	// 조직레벨 > 신한생명
				//tgrmCmnnhddvValu.setStrYmd("20220203");	// 진행일자
				tgrmCmnnhddvValu.setAcntOgnzNo("0911000");
			}
			
			List<String> happyCallListServiceId = Arrays.asList("ONNBC0250");
			if (happyCallListServiceId.contains(rcvSvcId)) {
				tgrmCmnnhddvValu.setDrtmCd("0995500");	// 조직
				tgrmCmnnhddvValu.setUserId("99999997");	// 인사 > 신한생명
				tgrmCmnnhddvValu.setAcntOgnzNo("0995500");
			}			
		}
		
		AppLog.debug("rcvSvcId : ["+rcvSvcId+"]");
		String paramStr;
		// 홈페이지 가입설계등록 - ScrnId 세팅
		if("HmpgEtplAgrSO.registHmpgEtplAgrInf".equals(rcvSvcId) ){
			
			tgrmCmnnhddvValu.setScrnId("cdhj0500");
			
			paramStr = MciUtil.toJsonString(inVo);//.replace("&quot;", "\\\"");
			AppLog.debug("line 153 =======================>>> tgrmCmnnhddvValu.getScrnId()[" + tgrmCmnnhddvValu.getScrnId() + "]");
			AppLog.debug("line 154 =======================>>> tgrmCmnnhddvValu.getUserIpAddr()[" + tgrmCmnnhddvValu.getUserIpAddr() + "]");
		}
		
		// 요청파라메터로 변경
	    paramStr = MciUtil.toJsonString(inVo);//.replace("&quot;", "\\\"");
		AppLog.debug("paramStr0[" + paramStr + "]");
		
		//21.11.26 -연금전환테스트 임의 수정 차후에 삭제해야 함.. 연금전환시 NL기준 미래상품만 존재하여 기준일자를 미래로 수정해서 진행해야함. start-->>>
//		if("ONCMM0010".equals(rcvSvcId) ){
//		AppLog.debug("line 163 =======================>>> tgrmCmnnhddvValu ONCMM0010[" + tgrmCmnnhddvValu.getStrYmd() + "]");
//			tgrmCmnnhddvValu.setStrYmd( "20220203" );
//		}
		//21.11.26 -연금전환테스트 임의 수정 차후에 삭제해야 함.. 연금전환시 NL기준 미래상품만 존재하여 기준일자를 미래로 수정해서 진행해야함. end-->>>
	
		
		//고객컨택센터 콜백 시 부서코드
		if("OCTPW0090".equals(rcvSvcId)) {
			tgrmCmnnhddvValu.setDrtmCd("0911000");     //drtmCd 부서코드 
		}

		AppLog.debug("line 184 =======================>>> tgrmCmnnhddvValu.getScrnId()[" + tgrmCmnnhddvValu.getScrnId() + "]");
		Method toMethod = inVo.getClass().getMethod("setTgrmCmnnhddvValu", MciCommHeaderVo.class);
				
		toMethod.invoke(inVo, tgrmCmnnhddvValu);
		
		AppLog.debug("line 189 =======================>>> tgrmCmnnhddvValu.getScrnId()[" + tgrmCmnnhddvValu.getScrnId() + "]");
		paramStr = MciUtil.toJsonString(inVo);//.replace("&quot;", "\\\"");
		AppLog.debug("line 191 =======================>>> paramStr[" + paramStr + "]");
		
		if(channel == null) {
			channel = MciChannelConst.NL_CDP;
		}
		
		// 요청파라메터로 변경
	    paramStr = MciUtil.toJsonString(inVo);//.replace("&quot;", "\\\"");
		AppLog.debug("paramStr1[" + paramStr + "]");
		
		return MciUtil.send(channel, inVo, outClass);
	}
	
	/**
	 * MCI 결과에서 전문처리결과코드 추출하여 "0" 성공 true, 그 외 false로 리턴한다.
	 * @param CommVO MCI결과 outVo
     * @return boolean 처리결과성공여부
	 * @throws Exception
     */
	public static boolean mciTgrmDalRsltCd(CommVO inVo) throws Exception {
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmCmnnhddvValu", new Class[0]);
			MciCommHeaderVo oMciCommHeaderVo = (MciCommHeaderVo)toMethod.invoke(inVo, new Object[0]);
			if("0".equals(oMciCommHeaderVo.getTgrmDalRsltCd())){
				return true;
			} 
		} catch(IndexOutOfBoundsException e) {
			AppLog.error(e.getMessage());
		}
		return false;
	}

	/**
	 * MCI 결과에서 전문메시지코드를 추출해서 리턴한다.
	 * @param CommVO MCI결과 outVo
     * @return String 전문메시지코드
	 * @throws Exception
     */
	public static String mciMsgCd(CommVO inVo) throws Exception {
		String msgCd = "";
		
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmMsdvValu", new Class[0]);
			MciCommMsgVo oMciCommMsgVo = (MciCommMsgVo)toMethod.invoke(inVo, new Object[0]);
			
			msgCd = oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCd();
			
		} catch(IndexOutOfBoundsException e) {
			msgCd = "ERROR";
			AppLog.error(e.getMessage());
		}
		return msgCd;
	}
	
	/**
	 * MCI 결과에서 전문메시지내용을 추출해서 리턴한다.
	 * @param CommVO MCI결과 outVo
     * @return String 전문메시지내용
	 * @throws Exception
     */
	public static String mciMsgCt(CommVO inVo) throws Exception {
		String msgCt = "";
		
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmMsdvValu", new Class[0]);
			MciCommMsgVo oMciCommMsgVo = (MciCommMsgVo)toMethod.invoke(inVo, new Object[0]);
			
			msgCt = oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCt();
			
		} catch(IndexOutOfBoundsException e) {
			msgCt = "ERROR";
			AppLog.error(e.getMessage());
		}
		return msgCt;
	}
	
	/**
	 * MCI 결과에서 전문메시지코드와 전문메시지내용을 추출해서 리턴한다.
	 * @param CommVO MCI결과 outVo
     * @return String 전문메시지코드+전문메시지내용
	 * @throws Exception
     */
	public static String mciMsgCdCt(CommVO inVo) throws Exception {
		String msgCdCt = "";
		
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmMsdvValu", new Class[0]);
			MciCommMsgVo oMciCommMsgVo = (MciCommMsgVo)toMethod.invoke(inVo, new Object[0]);
			
			msgCdCt += "[" + oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCd() + "]";
			msgCdCt += oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCt() + " ";
			
		} catch(IndexOutOfBoundsException e) {
			msgCdCt = "전문 에러";
			AppLog.error(e.getMessage());
		}
		return msgCdCt;
	}
	
	/**
	 * MCI 결과 헤더에서 인터페이스 ID를 추출해서 리턴한다.
	 * @param CommVO MCI결과 outVo
     * @return String 인터페이스ID
	 * @throws Exception
     */
	public static String mciItrfId(CommVO inVo) throws Exception {
		String itrfId = "";
		
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmCmnnhddvValu", new Class[0]);
			MciCommHeaderVo oMciCommHeaderVo = (MciCommHeaderVo)toMethod.invoke(inVo, new Object[0]);
			itrfId = oMciCommHeaderVo.getItrfId();
		} catch(IndexOutOfBoundsException e) {
			itrfId = "ERROR";
			AppLog.error(e.getMessage());
		}
		return itrfId;
	}
	
	/**
	 * MCI 결과 헤더에서 응답전문전송상세일시를 추출해서 리턴한다.
	 * @param CommVO MCI결과 outVo
	 * @return String 응답전문전송상세일시
	 * @throws Exception
	 */
	public static String mciRspnTgrmTnsmDtptDt(CommVO inVo) throws Exception {
		String rspnTgrmTnsmDtptDt = "";
		
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmCmnnhddvValu", new Class[0]);
			MciCommHeaderVo oMciCommHeaderVo = (MciCommHeaderVo)toMethod.invoke(inVo, new Object[0]);
			rspnTgrmTnsmDtptDt = oMciCommHeaderVo.getRspnTgrmTnsmDtptDt();
		} catch(IndexOutOfBoundsException e) {
			rspnTgrmTnsmDtptDt = "ERROR";
			AppLog.error(e.getMessage());
		}
		return rspnTgrmTnsmDtptDt;
	}

	/**
	 * MCI 결과에서 전문메시지코드를 추출해서 리턴한다.
	 * @param CommVO MCI결과 outVo
     * @return String 오류코드
	 * @throws Exception
     */
	public static String getErrorMsgCd(CommVO inVo) throws Exception {
		String msgCd = "";
		String msgCt = "";
		
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmMsdvValu", new Class[0]);
			MciCommMsgVo oMciCommMsgVo = (MciCommMsgVo)toMethod.invoke(inVo, new Object[0]);
			
			msgCd = oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCd();
			msgCt = oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCt();
			
			List<String> comMsgList = CommConfigCacheManager.getInstance().getList("dp.nnz-msg.com-msg-list");
			if(comMsgList.contains(msgCd)) {
				return "CDP00294";
			}
			
			CommMsgVo msgVo = CommMsgManager.getInstance().getMsg("ko", msgCd);
			if(msgVo == null) {
				/** 
				 * 화면에서 코드값 분기를 태워야할 상황을 대비해서
				 * resMsgVo 로 만들어서 리턴하기위해 만듬
				 * 수정하지마세요
				*/
				String errorMsgCdCt = "[" + msgCd + "]";
				errorMsgCdCt += msgCt;
				msgCd = errorMsgCdCt;
			}
		} catch(IndexOutOfBoundsException e ) {
			AppLog.error(e.getMessage());
			return "CDP00294";
		}
		
		return msgCd;
	}

	/**
	 * MCI 결과에서 전문메시지코드를 추출해서 리턴한다.
	 * @param CommVO MCI결과 outVo
     * @return String 오류코드
	 * @throws Exception
     */
	public static String getErrorMsgCdByDI(CommVO inVo) throws Exception {
		String msgCd = "";
		String msgCt = "";
		
		try {
			Method toMethod = inVo.getClass().getMethod("getTgrmMsdvValu", new Class[0]);
			MciCommMsgVo oMciCommMsgVo = (MciCommMsgVo)toMethod.invoke(inVo, new Object[0]);
			
			msgCd = oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCd();
			msgCt = oMciCommMsgVo.getMsgDtdvValu().get(0).getMsgCt();
			
			List<String> comMsgList = CommConfigCacheManager.getInstance().getList("dp.nnz-msg.com-msg-list");
			if(comMsgList.contains(msgCd)) {
				return "CDP00523";
			}
			
			CommMsgVo msgVo = CommMsgManager.getInstance().getMsg("ko", msgCd);
			if(msgVo == null) {
				/** 
				 * 화면에서 코드값 분기를 태워야할 상황을 대비해서
				 * resMsgVo 로 만들어서 리턴하기위해 만듬
				 * 수정하지마세요
				*/
				String errorMsgCdCt = "[" + msgCd + "]";
				errorMsgCdCt += msgCt;
				msgCd = errorMsgCdCt;
			}
		} catch(IndexOutOfBoundsException e ) {
			AppLog.error(e.getMessage());
			return "CDP00523";
		}
		
		return msgCd;
	}
}
