package chs.ccg.dp.co.mci.vo;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import com.inswave.elfw.exception.ElException;
import com.inswave.elfw.annotation.ElDto;
import com.inswave.elfw.annotation.ElDtoField;
import com.inswave.elfw.annotation.ElVoField;
import com.fasterxml.jackson.annotation.JsonFilter;
import com.inswave.elfw.log.AppLog;

@JsonFilter("elExcludeFilter")
@ElDto(FldYn = "Y", delimeterYn = "", logicalName = "NL MCI전문 공통헤더")
public class MciCommHeaderVo extends chs.ccg.dp.co.cmmn.CommCommVO {
    private static final long serialVersionUID = 1L;

    private int _offset;

    public MciCommHeaderVo(){
        this._offset = 0;
    }

    public MciCommHeaderVo(int iOffset){
        this._offset = iOffset;
    }

    @ElDtoField(logicalName = "전문길이", physicalName = "tgrmLencn", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 8, dotLen = 0, baseValue = "00000000", desc = "전체전문길이")
    private String tgrmLencn = "00000000";

    @ElDtoField(logicalName = "글로벌ID", physicalName = "glbId", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 37, dotLen = 0, baseValue = "", desc = "R] 생성일시(17)+hostname(9)+어플리케이션업무코드(3)+채번(8)")
    private String glbId;

    @ElDtoField(logicalName = "진행일련번호", physicalName = "pgrsSriaNo", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "", desc = "R] 순번(3)")
    private String pgrsSriaNo;

    @ElDtoField(logicalName = "전문버전정보값", physicalName = "trgmVrsnInfoValu", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "001", desc = "R]")
    private String trgmVrsnInfoValu = "001";

    @ElDtoField(logicalName = "전문암호화여부", physicalName = "tgrmEncrYn", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "0", desc = "R] 0:일반, 1:암호화 적용")
    private String tgrmEncrYn = "0";

    @ElDtoField(logicalName = "그룹사코드", physicalName = "gpcoCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 4, dotLen = 0, baseValue = "S016", desc = "R] 그룹사코드(신한생명:S016")
    private String gpcoCd = "S016";

    @ElDtoField(logicalName = "어플리케이션업무코드", physicalName = "appliDutjCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "", desc = "해당 전문을 생성한 채널계, 단위계, 응용 구분코드로 어플리케이션 3level이 3자리")
    private String appliDutjCd;

    @ElDtoField(logicalName = "어플리케이션상세업무코드", physicalName = "appliDtptDutjCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "DH1", desc = "해당 전문을 생성한 채널계에서 3자리 요청전문에 셋팅함, 3째자리 일련번호 규칙 : 앱(0), PC(1), 모바일웹(2), 홈페이지Web(DH1)MobWeb(DH2)..  ")
    private String appliDtptDutjCd = "DH1";

    @ElDtoField(logicalName = "대외기관코드", physicalName = "frbuCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 4, dotLen = 0, baseValue = "", desc = "대외MCI에서 정의한 기관, 업무 코드 표 참조(처리계에서 대외계 호출시에만 사용)")
    private String frbuCd;

    @ElDtoField(logicalName = "대외업무코드", physicalName = "cmouDutjCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 4, dotLen = 0, baseValue = "", desc = "대외MCI에서 정의한 기관, 업무 코드 표 참조(처리계에서 대외계 호출시에만 사용)")
    private String cmouDutjCd;

    @ElDtoField(logicalName = "대외종별코드", physicalName = "cmouCssfCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 8, dotLen = 0, baseValue = "", desc = "종별코드 - 대외기관 제공")
    private String cmouCssfCd;

    @ElDtoField(logicalName = "대외거래코드", physicalName = "cmouTraCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 32, dotLen = 0, baseValue = "", desc = "거래코드 - 대외기관 제공")
    private String cmouTraCd;

    @ElDtoField(logicalName = "수신서비스ID", physicalName = "rcvSvcId", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 120, dotLen = 0, baseValue = "", desc = "호출하고자 하는 타겟 시스템의 서비스 식별자")
    private String rcvSvcId;

    @ElDtoField(logicalName = "결과수신서비스ID", physicalName = "rsltRcvSvcId", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 120, dotLen = 0, baseValue = "", desc = "비동기 응답시 결과 수신 서비스 ID(10)")
    private String rsltRcvSvcId;

    @ElDtoField(logicalName = "전문생성채널유형코드", physicalName = "tgrmCreaChnnTypeCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "1", desc = "전문생성시스템구분 0:단말 1:채널계 2:단위계 3:처리계 4:대외기관")
    private String tgrmCreaChnnTypeCd = "1";

    @ElDtoField(logicalName = "언어구분코드", physicalName = "lnggDvsnCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 2, dotLen = 0, baseValue = "KR", desc = "메시지 다국어적용을 위해 필요한 항목 (현재는 메타에 다국어 메시지는 없으나 추후 필요할 수 있음)한국어[KR] 영어[EN]")
    private String lnggDvsnCd = "KR";

    @ElDtoField(logicalName = "시뮬레이션거래여부", physicalName = "simulTraYn", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "N", desc = "시뮬레이션 거래여부 체크 (개발/테스트환경에 사용하며 commit 안함) 여부(Y/N) 세팅")
    private String simulTraYn = "N";

    @ElDtoField(logicalName = "인터페이스ID", physicalName = "itrfId", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 20, dotLen = 0, baseValue = "", desc = "Interface 시스템의 서비스 식별자")
    private String itrfId;

    @ElDtoField(logicalName = "요청응답구분코드", physicalName = "reqRspnScCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "S", desc = "R] S:Send, R:Receive")
    private String reqRspnScCd = "S";

    @ElDtoField(logicalName = "전송유형코드", physicalName = "tnsmTypeCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "S", desc = "R] S:Sync, A:Async")
    private String tnsmTypeCd = "S";

    @ElDtoField(logicalName = "환경유형코드", physicalName = "envrTypeCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "", desc = "R] R:REAL, T:TEST, D: 개발")
    private String envrTypeCd;

    @ElDtoField(logicalName = "조회거래유형코드", physicalName = "inqrTraTypeCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "", desc = "R] 등록(C), 조회(R), 변경(U), 삭제(D), 인쇄(P), 다운로드(E) ")
    private String inqrTraTypeCd;

    @ElDtoField(logicalName = "요청전문전송상세일시", physicalName = "reqTgrmTnsmDtptDt", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 17, dotLen = 0, baseValue = "", desc = "R] YYYYMMDDHH24MISSFF3 (년-월-일-시-분-초-1/1000초)")
    private String reqTgrmTnsmDtptDt;

    @ElDtoField(logicalName = "기준일자", physicalName = "strYmd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 8, dotLen = 0, baseValue = "", desc = "미래날짜 TEST 등을 위한 화면에서 처리날짜를 셋팅해서 서버로 전달하는 값")
    private String strYmd;

    @ElDtoField(logicalName = "화면 ID", physicalName = "scrnId", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 40, dotLen = 0, baseValue = "", desc = "")
    private String scrnId;

    @ElDtoField(logicalName = "화면버튼ID", physicalName = "scrnBttnId", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 20, dotLen = 0, baseValue = "", desc = "프레임워크에서 권한 관리용으로 디폴트는 btn_Retrive로 세팅되고 특정 버튼에서 동작할땐 특정버튼명을 세팅함 ")
    private String scrnBttnId;

    @ElDtoField(logicalName = "사용자IP주소", physicalName = "userIpAddr", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 40, dotLen = 0, baseValue = "", desc = "")
    private String userIpAddr;

    @ElDtoField(logicalName = "부서코드", physicalName = "drtmCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 10, dotLen = 0, baseValue = "", desc = "부서(지점)코드")
    private String drtmCd;

    @ElDtoField(logicalName = "사용자ID", physicalName = "userId", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 20, dotLen = 0, baseValue = "", desc = "사번 또는 아이디")
    private String userId;

    @ElDtoField(logicalName = "개인신용정보역할코드", physicalName = "indvCtinRoleCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "", desc = "개인신용정보역할코드. 해당값은 수금에 문의")
    private String indvCtinRoleCd;

    @ElDtoField(logicalName = "경리조직번호", physicalName = "acntOgnzNo", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 7, dotLen = 0, baseValue = "", desc = "경리조직번호 해당값은 재무회계에 문의")
    private String acntOgnzNo;

    @ElDtoField(logicalName = "응답전문전송상세일시", physicalName = "rspnTgrmTnsmDtptDt", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "Yes", cryptoGbn = "", cryptoKind = "", length = 17, dotLen = 0, baseValue = "", desc = "YYYYMMDDHH24MISSFF3 (년-월-일-시-분-초-1/1000초)")
    private String rspnTgrmTnsmDtptDt;

    @ElDtoField(logicalName = "전문처리결과코드", physicalName = "tgrmDalRsltCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "", desc = "0:정상, 1:오류 ")
    private String tgrmDalRsltCd;

    @ElDtoField(logicalName = "조직분류코드", physicalName = "ognzAsrtCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 2, dotLen = 0, baseValue = "", desc = "권한관리")
    private String ognzAsrtCd;

    @ElDtoField(logicalName = "조직레벨코드", physicalName = "ognzLeveCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 2, dotLen = 0, baseValue = "ZZ", desc = "권한관리")
    private String ognzLeveCd = "ZZ";

    @ElDtoField(logicalName = "인사조직분류코드", physicalName = "psmrAsrtCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "", desc = "권한관리")
    private String psmrAsrtCd;

    @ElDtoField(logicalName = "영업규정분류코드", physicalName = "sbsnRulpAsrtCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "", desc = "권한관리")
    private String sbsnRulpAsrtCd;

    @ElDtoField(logicalName = "영업직책코드", physicalName = "bsduCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 3, dotLen = 0, baseValue = "", desc = "권한관리")
    private String bsduCd;

    @ElDtoField(logicalName = "영업자격코드", physicalName = "bsquCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 2, dotLen = 0, baseValue = "", desc = "권한관리")
    private String bsquCd;

    @ElDtoField(logicalName = "연계인사직책코드", physicalName = "linkPrafDutyCd", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 10, dotLen = 0, baseValue = "", desc = "결재권자관리")
    private String linkPrafDutyCd;

    @ElDtoField(logicalName = "개인정보로그작성여부", physicalName = "indvInfoLogWritYn", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 1, dotLen = 0, baseValue = "N", desc = "요청전문 default : N, 처리계(프레임워크)에서 개인정보 로그를 남긴 후 응답전문 : Y, 그외 : N 셋팅")
    private String indvInfoLogWritYn = "N";

    @ElDtoField(logicalName = "예비항목명", physicalName = "prepImhdNm", type = "String", typeKind = "", fldYn = "Yes", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 213, dotLen = 0, baseValue = "", desc = "예비영역")
    private String prepImhdNm;

    @ElVoField(physicalName = "tgrmLencn")
    public String getTgrmLencn(){
        return tgrmLencn;
    }

    @ElVoField(physicalName = "tgrmLencn")
    public void setTgrmLencn(String tgrmLencn){
        this.tgrmLencn = tgrmLencn;
    }

    @ElVoField(physicalName = "glbId")
    public String getGlbId(){
        return glbId;
    }

    @ElVoField(physicalName = "glbId")
    public void setGlbId(String glbId){
        this.glbId = glbId;
    }

    @ElVoField(physicalName = "pgrsSriaNo")
    public String getPgrsSriaNo(){
        return pgrsSriaNo;
    }

    @ElVoField(physicalName = "pgrsSriaNo")
    public void setPgrsSriaNo(String pgrsSriaNo){
        this.pgrsSriaNo = pgrsSriaNo;
    }

    @ElVoField(physicalName = "trgmVrsnInfoValu")
    public String getTrgmVrsnInfoValu(){
        return trgmVrsnInfoValu;
    }

    @ElVoField(physicalName = "trgmVrsnInfoValu")
    public void setTrgmVrsnInfoValu(String trgmVrsnInfoValu){
        this.trgmVrsnInfoValu = trgmVrsnInfoValu;
    }

    @ElVoField(physicalName = "tgrmEncrYn")
    public String getTgrmEncrYn(){
        return tgrmEncrYn;
    }

    @ElVoField(physicalName = "tgrmEncrYn")
    public void setTgrmEncrYn(String tgrmEncrYn){
        this.tgrmEncrYn = tgrmEncrYn;
    }

    @ElVoField(physicalName = "gpcoCd")
    public String getGpcoCd(){
        return gpcoCd;
    }

    @ElVoField(physicalName = "gpcoCd")
    public void setGpcoCd(String gpcoCd){
        this.gpcoCd = gpcoCd;
    }

    @ElVoField(physicalName = "appliDutjCd")
    public String getAppliDutjCd(){
        return appliDutjCd;
    }

    @ElVoField(physicalName = "appliDutjCd")
    public void setAppliDutjCd(String appliDutjCd){
        this.appliDutjCd = appliDutjCd;
    }

    @ElVoField(physicalName = "appliDtptDutjCd")
    public String getAppliDtptDutjCd(){
        return appliDtptDutjCd;
    }

    @ElVoField(physicalName = "appliDtptDutjCd")
    public void setAppliDtptDutjCd(String appliDtptDutjCd){
        this.appliDtptDutjCd = appliDtptDutjCd;
    }

    @ElVoField(physicalName = "frbuCd")
    public String getFrbuCd(){
        return frbuCd;
    }

    @ElVoField(physicalName = "frbuCd")
    public void setFrbuCd(String frbuCd){
        this.frbuCd = frbuCd;
    }

    @ElVoField(physicalName = "cmouDutjCd")
    public String getCmouDutjCd(){
        return cmouDutjCd;
    }

    @ElVoField(physicalName = "cmouDutjCd")
    public void setCmouDutjCd(String cmouDutjCd){
        this.cmouDutjCd = cmouDutjCd;
    }

    @ElVoField(physicalName = "cmouCssfCd")
    public String getCmouCssfCd(){
        return cmouCssfCd;
    }

    @ElVoField(physicalName = "cmouCssfCd")
    public void setCmouCssfCd(String cmouCssfCd){
        this.cmouCssfCd = cmouCssfCd;
    }

    @ElVoField(physicalName = "cmouTraCd")
    public String getCmouTraCd(){
        return cmouTraCd;
    }

    @ElVoField(physicalName = "cmouTraCd")
    public void setCmouTraCd(String cmouTraCd){
        this.cmouTraCd = cmouTraCd;
    }

    @ElVoField(physicalName = "rcvSvcId")
    public String getRcvSvcId(){
        return rcvSvcId;
    }

    @ElVoField(physicalName = "rcvSvcId")
    public void setRcvSvcId(String rcvSvcId){
        this.rcvSvcId = rcvSvcId;
    }

    @ElVoField(physicalName = "rsltRcvSvcId")
    public String getRsltRcvSvcId(){
        return rsltRcvSvcId;
    }

    @ElVoField(physicalName = "rsltRcvSvcId")
    public void setRsltRcvSvcId(String rsltRcvSvcId){
        this.rsltRcvSvcId = rsltRcvSvcId;
    }

    @ElVoField(physicalName = "tgrmCreaChnnTypeCd")
    public String getTgrmCreaChnnTypeCd(){
        return tgrmCreaChnnTypeCd;
    }

    @ElVoField(physicalName = "tgrmCreaChnnTypeCd")
    public void setTgrmCreaChnnTypeCd(String tgrmCreaChnnTypeCd){
        this.tgrmCreaChnnTypeCd = tgrmCreaChnnTypeCd;
    }

    @ElVoField(physicalName = "lnggDvsnCd")
    public String getLnggDvsnCd(){
        return lnggDvsnCd;
    }

    @ElVoField(physicalName = "lnggDvsnCd")
    public void setLnggDvsnCd(String lnggDvsnCd){
        this.lnggDvsnCd = lnggDvsnCd;
    }

    @ElVoField(physicalName = "simulTraYn")
    public String getSimulTraYn(){
        return simulTraYn;
    }

    @ElVoField(physicalName = "simulTraYn")
    public void setSimulTraYn(String simulTraYn){
        this.simulTraYn = simulTraYn;
    }

    @ElVoField(physicalName = "itrfId")
    public String getItrfId(){
        return itrfId;
    }

    @ElVoField(physicalName = "itrfId")
    public void setItrfId(String itrfId){
        this.itrfId = itrfId;
    }

    @ElVoField(physicalName = "reqRspnScCd")
    public String getReqRspnScCd(){
        return reqRspnScCd;
    }

    @ElVoField(physicalName = "reqRspnScCd")
    public void setReqRspnScCd(String reqRspnScCd){
        this.reqRspnScCd = reqRspnScCd;
    }

    @ElVoField(physicalName = "tnsmTypeCd")
    public String getTnsmTypeCd(){
        return tnsmTypeCd;
    }

    @ElVoField(physicalName = "tnsmTypeCd")
    public void setTnsmTypeCd(String tnsmTypeCd){
        this.tnsmTypeCd = tnsmTypeCd;
    }

    @ElVoField(physicalName = "envrTypeCd")
    public String getEnvrTypeCd(){
        return envrTypeCd;
    }

    @ElVoField(physicalName = "envrTypeCd")
    public void setEnvrTypeCd(String envrTypeCd){
        this.envrTypeCd = envrTypeCd;
    }

    @ElVoField(physicalName = "inqrTraTypeCd")
    public String getInqrTraTypeCd(){
        return inqrTraTypeCd;
    }

    @ElVoField(physicalName = "inqrTraTypeCd")
    public void setInqrTraTypeCd(String inqrTraTypeCd){
        this.inqrTraTypeCd = inqrTraTypeCd;
    }

    @ElVoField(physicalName = "reqTgrmTnsmDtptDt")
    public String getReqTgrmTnsmDtptDt(){
        return reqTgrmTnsmDtptDt;
    }

    @ElVoField(physicalName = "reqTgrmTnsmDtptDt")
    public void setReqTgrmTnsmDtptDt(String reqTgrmTnsmDtptDt){
        this.reqTgrmTnsmDtptDt = reqTgrmTnsmDtptDt;
    }

    @ElVoField(physicalName = "strYmd")
    public String getStrYmd(){
        return strYmd;
    }

    @ElVoField(physicalName = "strYmd")
    public void setStrYmd(String strYmd){
        this.strYmd = strYmd;
    }

    @ElVoField(physicalName = "scrnId")
    public String getScrnId(){
        return scrnId;
    }

    @ElVoField(physicalName = "scrnId")
    public void setScrnId(String scrnId){
        this.scrnId = scrnId;
    }

    @ElVoField(physicalName = "scrnBttnId")
    public String getScrnBttnId(){
        return scrnBttnId;
    }

    @ElVoField(physicalName = "scrnBttnId")
    public void setScrnBttnId(String scrnBttnId){
        this.scrnBttnId = scrnBttnId;
    }

    @ElVoField(physicalName = "userIpAddr")
    public String getUserIpAddr(){
        return userIpAddr;
    }

    @ElVoField(physicalName = "userIpAddr")
    public void setUserIpAddr(String userIpAddr){
        this.userIpAddr = userIpAddr;
    }

    @ElVoField(physicalName = "drtmCd")
    public String getDrtmCd(){
        return drtmCd;
    }

    @ElVoField(physicalName = "drtmCd")
    public void setDrtmCd(String drtmCd){
        this.drtmCd = drtmCd;
    }

    @ElVoField(physicalName = "userId")
    public String getUserId(){
        return userId;
    }

    @ElVoField(physicalName = "userId")
    public void setUserId(String userId){
        this.userId = userId;
    }

    @ElVoField(physicalName = "indvCtinRoleCd")
    public String getIndvCtinRoleCd(){
        return indvCtinRoleCd;
    }

    @ElVoField(physicalName = "indvCtinRoleCd")
    public void setIndvCtinRoleCd(String indvCtinRoleCd){
        this.indvCtinRoleCd = indvCtinRoleCd;
    }

    @ElVoField(physicalName = "acntOgnzNo")
    public String getAcntOgnzNo(){
        return acntOgnzNo;
    }

    @ElVoField(physicalName = "acntOgnzNo")
    public void setAcntOgnzNo(String acntOgnzNo){
        this.acntOgnzNo = acntOgnzNo;
    }

    @ElVoField(physicalName = "rspnTgrmTnsmDtptDt")
    public String getRspnTgrmTnsmDtptDt(){
        return rspnTgrmTnsmDtptDt;
    }

    @ElVoField(physicalName = "rspnTgrmTnsmDtptDt")
    public void setRspnTgrmTnsmDtptDt(String rspnTgrmTnsmDtptDt){
        this.rspnTgrmTnsmDtptDt = rspnTgrmTnsmDtptDt;
    }

    @ElVoField(physicalName = "tgrmDalRsltCd")
    public String getTgrmDalRsltCd(){
        return tgrmDalRsltCd;
    }

    @ElVoField(physicalName = "tgrmDalRsltCd")
    public void setTgrmDalRsltCd(String tgrmDalRsltCd){
        this.tgrmDalRsltCd = tgrmDalRsltCd;
    }

    @ElVoField(physicalName = "ognzAsrtCd")
    public String getOgnzAsrtCd(){
        return ognzAsrtCd;
    }

    @ElVoField(physicalName = "ognzAsrtCd")
    public void setOgnzAsrtCd(String ognzAsrtCd){
        this.ognzAsrtCd = ognzAsrtCd;
    }

    @ElVoField(physicalName = "ognzLeveCd")
    public String getOgnzLeveCd(){
        return ognzLeveCd;
    }

    @ElVoField(physicalName = "ognzLeveCd")
    public void setOgnzLeveCd(String ognzLeveCd){
        this.ognzLeveCd = ognzLeveCd;
    }

    @ElVoField(physicalName = "psmrAsrtCd")
    public String getPsmrAsrtCd(){
        return psmrAsrtCd;
    }

    @ElVoField(physicalName = "psmrAsrtCd")
    public void setPsmrAsrtCd(String psmrAsrtCd){
        this.psmrAsrtCd = psmrAsrtCd;
    }

    @ElVoField(physicalName = "sbsnRulpAsrtCd")
    public String getSbsnRulpAsrtCd(){
        return sbsnRulpAsrtCd;
    }

    @ElVoField(physicalName = "sbsnRulpAsrtCd")
    public void setSbsnRulpAsrtCd(String sbsnRulpAsrtCd){
        this.sbsnRulpAsrtCd = sbsnRulpAsrtCd;
    }

    @ElVoField(physicalName = "bsduCd")
    public String getBsduCd(){
        return bsduCd;
    }

    @ElVoField(physicalName = "bsduCd")
    public void setBsduCd(String bsduCd){
        this.bsduCd = bsduCd;
    }

    @ElVoField(physicalName = "bsquCd")
    public String getBsquCd(){
        return bsquCd;
    }

    @ElVoField(physicalName = "bsquCd")
    public void setBsquCd(String bsquCd){
        this.bsquCd = bsquCd;
    }

    @ElVoField(physicalName = "linkPrafDutyCd")
    public String getLinkPrafDutyCd(){
        return linkPrafDutyCd;
    }

    @ElVoField(physicalName = "linkPrafDutyCd")
    public void setLinkPrafDutyCd(String linkPrafDutyCd){
        this.linkPrafDutyCd = linkPrafDutyCd;
    }

    @ElVoField(physicalName = "indvInfoLogWritYn")
    public String getIndvInfoLogWritYn(){
        return indvInfoLogWritYn;
    }

    @ElVoField(physicalName = "indvInfoLogWritYn")
    public void setIndvInfoLogWritYn(String indvInfoLogWritYn){
        this.indvInfoLogWritYn = indvInfoLogWritYn;
    }

    @ElVoField(physicalName = "prepImhdNm")
    public String getPrepImhdNm(){
        return prepImhdNm;
    }

    @ElVoField(physicalName = "prepImhdNm")
    public void setPrepImhdNm(String prepImhdNm){
        this.prepImhdNm = prepImhdNm;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("MciCommHeaderVo [");
        sb.append("tgrmLencn").append("=").append(tgrmLencn).append(",");
        sb.append("glbId").append("=").append(glbId).append(",");
        sb.append("pgrsSriaNo").append("=").append(pgrsSriaNo).append(",");
        sb.append("trgmVrsnInfoValu").append("=").append(trgmVrsnInfoValu).append(",");
        sb.append("tgrmEncrYn").append("=").append(tgrmEncrYn).append(",");
        sb.append("gpcoCd").append("=").append(gpcoCd).append(",");
        sb.append("appliDutjCd").append("=").append(appliDutjCd).append(",");
        sb.append("appliDtptDutjCd").append("=").append(appliDtptDutjCd).append(",");
        sb.append("frbuCd").append("=").append(frbuCd).append(",");
        sb.append("cmouDutjCd").append("=").append(cmouDutjCd).append(",");
        sb.append("cmouCssfCd").append("=").append(cmouCssfCd).append(",");
        sb.append("cmouTraCd").append("=").append(cmouTraCd).append(",");
        sb.append("rcvSvcId").append("=").append(rcvSvcId).append(",");
        sb.append("rsltRcvSvcId").append("=").append(rsltRcvSvcId).append(",");
        sb.append("tgrmCreaChnnTypeCd").append("=").append(tgrmCreaChnnTypeCd).append(",");
        sb.append("lnggDvsnCd").append("=").append(lnggDvsnCd).append(",");
        sb.append("simulTraYn").append("=").append(simulTraYn).append(",");
        sb.append("itrfId").append("=").append(itrfId).append(",");
        sb.append("reqRspnScCd").append("=").append(reqRspnScCd).append(",");
        sb.append("tnsmTypeCd").append("=").append(tnsmTypeCd).append(",");
        sb.append("envrTypeCd").append("=").append(envrTypeCd).append(",");
        sb.append("inqrTraTypeCd").append("=").append(inqrTraTypeCd).append(",");
        sb.append("reqTgrmTnsmDtptDt").append("=").append(reqTgrmTnsmDtptDt).append(",");
        sb.append("strYmd").append("=").append(strYmd).append(",");
        sb.append("scrnId").append("=").append(scrnId).append(",");
        sb.append("scrnBttnId").append("=").append(scrnBttnId).append(",");
        sb.append("userIpAddr").append("=").append(userIpAddr).append(",");
        sb.append("drtmCd").append("=").append(drtmCd).append(",");
        sb.append("userId").append("=").append(userId).append(",");
        sb.append("indvCtinRoleCd").append("=").append(indvCtinRoleCd).append(",");
        sb.append("acntOgnzNo").append("=").append(acntOgnzNo).append(",");
        sb.append("rspnTgrmTnsmDtptDt").append("=").append(rspnTgrmTnsmDtptDt).append(",");
        sb.append("tgrmDalRsltCd").append("=").append(tgrmDalRsltCd).append(",");
        sb.append("ognzAsrtCd").append("=").append(ognzAsrtCd).append(",");
        sb.append("ognzLeveCd").append("=").append(ognzLeveCd).append(",");
        sb.append("psmrAsrtCd").append("=").append(psmrAsrtCd).append(",");
        sb.append("sbsnRulpAsrtCd").append("=").append(sbsnRulpAsrtCd).append(",");
        sb.append("bsduCd").append("=").append(bsduCd).append(",");
        sb.append("bsquCd").append("=").append(bsquCd).append(",");
        sb.append("linkPrafDutyCd").append("=").append(linkPrafDutyCd).append(",");
        sb.append("indvInfoLogWritYn").append("=").append(indvInfoLogWritYn).append(",");
        sb.append("prepImhdNm").append("=").append(prepImhdNm);
        sb.append("]");
        return sb.toString();

    }

    public boolean isFixedLengthVo() {
        return true;
    }

    public byte[] marshalFld() throws IOException{
        return marshalFld( com.inswave.elfw.ElConfig.getFldEncode() ); 
    }

	public byte[] marshalFld(String encode) throws IOException{
    	ByteArrayOutputStream bout = new ByteArrayOutputStream();
        DataOutputStream out = null;
        try {
            out = new DataOutputStream(bout);
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.tgrmLencn , 8, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.glbId , 37, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.pgrsSriaNo , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.trgmVrsnInfoValu , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.tgrmEncrYn , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.gpcoCd , 4, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.appliDutjCd , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.appliDtptDutjCd , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.frbuCd , 4, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.cmouDutjCd , 4, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.cmouCssfCd , 8, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.cmouTraCd , 32, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.rcvSvcId , 120, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.rsltRcvSvcId , 120, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.tgrmCreaChnnTypeCd , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.lnggDvsnCd , 2, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.simulTraYn , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.itrfId , 20, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.reqRspnScCd , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.tnsmTypeCd , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.envrTypeCd , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.inqrTraTypeCd , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.reqTgrmTnsmDtptDt , 17, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.strYmd , 8, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.scrnId , 40, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.scrnBttnId , 20, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.userIpAddr , 40, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.drtmCd , 10, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.userId , 20, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.indvCtinRoleCd , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.acntOgnzNo , 7, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.rspnTgrmTnsmDtptDt , 17, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.tgrmDalRsltCd , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.ognzAsrtCd , 2, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.ognzLeveCd , 2, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.psmrAsrtCd , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.sbsnRulpAsrtCd , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.bsduCd , 3, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.bsquCd , 2, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.linkPrafDutyCd , 10, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.indvInfoLogWritYn , 1, encode ) );
            out.write( com.inswave.elfw.util.TypeConversionUtil.strToSpBytes(this.prepImhdNm , 213, encode ) );
        } catch (IOException e) {
                AppLog.error("marshalFld Error:["+ toString()+"]", e);
                throw e;
        } finally {
            try	{
                if (out != null) out.close();
           } catch (IOException ie) {
                AppLog.error("marshalFld out close Error", ie);
           }
            try	{
                if (bout != null) bout.close();
           } catch (IOException ie) {
                AppLog.error("marshalFld bout close Error", ie);
           }
        }
        return bout.toByteArray();
    }

    public void unMarshalFld( byte[] bytes ) throws ElException{
        unMarshalFld( bytes, com.inswave.elfw.ElConfig.getFldEncode() ); 
    }

    public void unMarshalFld( byte[] bytes , String encode) throws ElException{
        try{ 
            this.tgrmLencn = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 8, encode );
             _offset += 8;
            this.glbId = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 37, encode );
             _offset += 37;
            this.pgrsSriaNo = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.trgmVrsnInfoValu = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.tgrmEncrYn = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.gpcoCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 4, encode );
             _offset += 4;
            this.appliDutjCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.appliDtptDutjCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.frbuCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 4, encode );
             _offset += 4;
            this.cmouDutjCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 4, encode );
             _offset += 4;
            this.cmouCssfCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 8, encode );
             _offset += 8;
            this.cmouTraCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 32, encode );
             _offset += 32;
            this.rcvSvcId = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 120, encode );
             _offset += 120;
            this.rsltRcvSvcId = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 120, encode );
             _offset += 120;
            this.tgrmCreaChnnTypeCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.lnggDvsnCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 2, encode );
             _offset += 2;
            this.simulTraYn = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.itrfId = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 20, encode );
             _offset += 20;
            this.reqRspnScCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.tnsmTypeCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.envrTypeCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.inqrTraTypeCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.reqTgrmTnsmDtptDt = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 17, encode );
             _offset += 17;
            this.strYmd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 8, encode );
             _offset += 8;
            this.scrnId = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 40, encode );
             _offset += 40;
            this.scrnBttnId = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 20, encode );
             _offset += 20;
            this.userIpAddr = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 40, encode );
             _offset += 40;
            this.drtmCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 10, encode );
             _offset += 10;
            this.userId = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 20, encode );
             _offset += 20;
            this.indvCtinRoleCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.acntOgnzNo = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 7, encode );
             _offset += 7;
            this.rspnTgrmTnsmDtptDt = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 17, encode );
             _offset += 17;
            this.tgrmDalRsltCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.ognzAsrtCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 2, encode );
             _offset += 2;
            this.ognzLeveCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 2, encode );
             _offset += 2;
            this.psmrAsrtCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.sbsnRulpAsrtCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.bsduCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 3, encode );
             _offset += 3;
            this.bsquCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 2, encode );
             _offset += 2;
            this.linkPrafDutyCd = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 10, encode );
             _offset += 10;
            this.indvInfoLogWritYn = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 1, encode );
             _offset += 1;
            this.prepImhdNm = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, _offset, 213, encode );
             _offset += 213;
        }catch(ElException e) { 
            String errorLine = com.inswave.elfw.util.TypeConversionUtil.getTrimmedString( bytes, 0, bytes.length, encode );
            AppLog.error("unMarshalFld Error:["+ errorLine+"]", e);
            throw e;
        } 
    }

    public int getOffset(){
        return _offset;
    }

    @Override
    public void _xStreamEnc() {
    }


    @Override
    public void _xStreamDec() {
    }


}
