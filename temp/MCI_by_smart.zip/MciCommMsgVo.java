package chs.ccg.dp.co.mci.vo;

import com.inswave.elfw.annotation.ElDto;
import com.inswave.elfw.annotation.ElDtoField;
import com.fasterxml.jackson.annotation.JsonFilter;

@JsonFilter("elExcludeFilter")
@ElDto(FldYn = "", delimeterYn = "", logicalName = "MCI 응답 메시지부 VO")
public class MciCommMsgVo extends chs.ccg.dp.co.cmmn.CommCommVO {
    private static final long serialVersionUID = 1L;

    public MciCommMsgVo(){
    }

    @ElDtoField(logicalName = "MCI 응답 메시지헤더부 VO", physicalName = "msgHddvValu", type = "", typeKind = "Vo", fldYn = "No", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 0, dotLen = 0, baseValue = "", desc = "")
    private chs.ccg.dp.co.mci.vo.MciCommMsgHdrVo msgHddvValu;

    @ElDtoField(logicalName = "MCI 응답 메시지데이터부 List", physicalName = "msgDtdvValu", type = "", typeKind = "List", fldYn = "No", delimeterYn = "", cryptoGbn = "", cryptoKind = "", length = 0, dotLen = 0, baseValue = "", desc = "")
    private java.util.List<chs.ccg.dp.co.mci.vo.MciCommMsgDataVo> msgDtdvValu;

    public chs.ccg.dp.co.mci.vo.MciCommMsgHdrVo getMsgHddvValu(){
        return msgHddvValu;
    }

    public void setMsgHddvValu(chs.ccg.dp.co.mci.vo.MciCommMsgHdrVo msgHddvValu){
        this.msgHddvValu = msgHddvValu;
    }

    public java.util.List<chs.ccg.dp.co.mci.vo.MciCommMsgDataVo> getMsgDtdvValu(){
        return msgDtdvValu;
    }

    public void setMsgDtdvValu(java.util.List<chs.ccg.dp.co.mci.vo.MciCommMsgDataVo> msgDtdvValu){
        this.msgDtdvValu = msgDtdvValu;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("MciCommMsgVo [");
        sb.append("msgHddvValu").append("=").append(msgHddvValu).append(",");
        sb.append("msgDtdvValu").append("=").append(msgDtdvValu);
        sb.append("]");
        return sb.toString();

    }

    public boolean isFixedLengthVo() {
        return false;
    }

    @Override
    public void _xStreamEnc() {
        if( this.msgHddvValu != null ) this.msgHddvValu._xStreamEnc();
        for( int i=0 ; msgDtdvValu != null && i < msgDtdvValu.size() ; i++ ) {
            chs.ccg.dp.co.mci.vo.MciCommMsgDataVo vo = (chs.ccg.dp.co.mci.vo.MciCommMsgDataVo)msgDtdvValu.get(i);
            vo._xStreamEnc();	 
        }
    }


    @Override
    public void _xStreamDec() {
        if( this.msgHddvValu != null ) this.msgHddvValu._xStreamDec();
        for( int i=0 ; msgDtdvValu != null && i < msgDtdvValu.size() ; i++ ) {
            chs.ccg.dp.co.mci.vo.MciCommMsgDataVo vo = (chs.ccg.dp.co.mci.vo.MciCommMsgDataVo)msgDtdvValu.get(i);
            vo._xStreamDec();	 
        }
    }


}
