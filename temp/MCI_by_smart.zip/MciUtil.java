package chs.ccg.dp.co.mci;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.inswave.elfw.ElConfig;
import com.inswave.elfw.core.CommVO;
import com.inswave.elfw.core.ElHeader;
import com.inswave.elfw.databind.DefaultPropertyNamingStrategy;
import com.inswave.elfw.log.AppLog;
import com.inswave.elfw.util.CommUtil;
import com.inswave.elfw.util.DateUtil;
import com.inswave.elfw.util.TypeConversionUtil;
import com.inswave.elfw.view.ElMappingJacksonObjectMapper;

import chs.ccg.dp.co.cmmn.CommCommVO;
import chs.ccg.dp.co.cmmn.CommUserHeader;
import chs.ccg.dp.co.cmmn.util.CcContextUtil;
import chs.ccg.dp.co.cmmn.util.CcFwUtil;
import chs.ccg.dp.co.cmmn.util.DpStringUtil;
import chs.ccg.dp.co.dblog.MciDBLog;
import chs.ccg.dp.co.dblog.MciDBLogVo;
import chs.ccg.dp.co.mci.cmou.vo.MciHfldMsgVo;
import chs.ccg.dp.co.mci.vo.MciCommHeaderVo;

public class MciUtil {
	/**
	 * MCI채널에 전문 송신하고 응답받기(SL_MCI용, FLD) 
	 * @param channel
	 * @param userHeader
	 * @param inVo
	 * @param outVo
	 * @param timeoutMs	시간제한 0보다 크면 적용됨
	 * @return
	 * @throws Exception 
	 */
	/*
	public static ElResDataVO send(MciChannelConst channel, CcSlMciUserHeader reqHeader, CommVO inVo, Class outClass) throws Exception {
		return send(channel,reqHeader,inVo,outClass, 0);
	}
	
	public static ElResDataVO send(MciChannelConst channel, CcSlMciUserHeader reqHeader, CommVO inVo, Class outClass, int timeoutMs) throws Exception {
		// TODO : 관리자페이지 - 채널/전문 차단여부 체크
		String chType = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_TYPE");
		if (!"FLD".equalsIgnoreCase(chType)) {
			throw new Exception(channel.name()+" FLD타입이 아님");
		}
		String chUrl = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_BASE_URL");
		String[] strArr = chUrl.split(":");
		String host = strArr[0];
		String portStr = strArr.length > 1 ? strArr[1] : null;
		
		// DEBUG일때만 validation
		if(AppLog.isDebugEnabled()) {
			if (host == null) throw new Exception("MCI_PORP 그룹, "+channel.name()+"_BASE_URL 설정안됨");
			if (portStr == null) throw new Exception("MCI_PORP 그룹, "+channel.name()+"_BASE_URL 비정상");	

			_validate(reqHeader);
		}
		
		int port = TypeConversionUtil.parseToInt(portStr);

		// 공통헤더에 자동세팅 가능한 부분 처리
		ElHeader elHeader = CcContextUtil.getElHeader();
		if (reqHeader.getGlobalNo() == null) {
			reqHeader.setGlobalNo(_nextGlobalNo(reqHeader.getApplCd()));
		}
		reqHeader.setSystemCd("1");
		reqHeader.setEnvrFlag("T");
		reqHeader.setTtlFlag(1);
		reqHeader.setSendTime(DateUtil.getNow("yyyyMMddHHmmssSSS").substring(0, 16));
		reqHeader.setClntIp(elHeader.getClientIp());
		if(DpStringUtil.isNotEmpty(elHeader.getUserId())) {
			reqHeader.setUserId(elHeader.getUserId());
		}

// FLD 전문 찍기위해 sendFld 내부 로직 import함
//		ElResDataVO resVo = CommTcpLengthBaseSendUtil.sendFld(host, port, reqHeader, inVo, outClass
//		, 8			// 최초 길이컬럼 바이트 수
//		, true		// 길이컬럼에 길이컬럼도 포함한 전체바이트수 세팅 여부
//		/*, "EUC-KR"*//*);

		if(AppLog.isDebugEnabled()){
			AppLog.debug("req header:" + reqHeader);
			AppLog.debug("req   body:" + inVo);			
		} 
		
		byte reqBytes[] = ElFldConverter.voToFld(reqHeader, inVo);

		// TODO : 전문 Logging - 요청전문
		// 로그정상적으로 찍기위해 8바이트짜리 길이 세팅
		if (reqBytes != null) {
			int iWriteLengthFieldValue = reqBytes.length;
			byte[] bWriteLengthFieldValue = TypeConversionUtil.intToBytes(iWriteLengthFieldValue, 8);
			System.arraycopy(bWriteLengthFieldValue, 0, reqBytes, 0, 8);
		}

		String ifId = reqHeader.getPfmAppName() + "." + reqHeader.getPfmSvcName() + "."+ reqHeader.getPfmFnName();
		
		AppLog.debug(channel+" Send "+ new String(reqBytes,ElConfig.getFldEncode()));
		MciDBLogVo logVo = null;
		if (MciDBLog.isEnabled(ifId)) {
			logVo = MciDBLog.getLogVo(channel.name(), chType, chUrl, ifId, timeoutMs, new String(reqBytes,ElConfig.getFldEncode()));
		}
		
		byte resBytes[] = null;
		try {
			resBytes = ElTcpUtil.sendLengthTcp(host, port, reqBytes, 8, 1024, ElConfig.getFldEncode(), true, timeoutMs);
			String resStr = new String(resBytes,ElConfig.getFldEncode());
			AppLog.debug(channel+" Recv "+ resStr);

			ElResDataVO resVo = CommTcpLengthBaseSendUtil.fldToVo(resBytes, reqHeader.getClass(), outClass);
			CcSlMciUserHeader resHeader =(CcSlMciUserHeader)resVo.getUserHeader();
			Exception ue = null;
			if (!"0".equals(resHeader.getResType())) {
				ue = new Exception("오류수신:"+resHeader.getResCode()+"-"+resHeader.getResBascMsg());
			} 
			// 전문 Logging - 성공시
			MciDBLog.write(logVo, resStr, ue);
			logVo = null;

			if(AppLog.isDebugEnabled()) {
				AppLog.debug("res header:" + resHeader);
				AppLog.debug("res   body:" + resVo.getVo());
			}		
			return resVo;
		} catch(NullPointerException e){	// sparrow
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, "", e);
			}
			throw e;
		} catch(Exception e){
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, "", e);
			}
			throw e;
		}
// FLD 전문 찍기위해 sendFld 내부 로직 import함 -- 여기까지
	}*/
	
	/**
	 * MCI채널에 전문 송신하고 응답받기(OL_SOAP용, SOAP) (2021-02-08)in/out vo는 CcOlSopaClient에 바로 bypass하는 것으로 변경
	 * @param channel
	 * @param soapId
	 * @param inVo
	 * @param outClass
	 * @param timeoutMs	0보다크면 적용됨 - soap은 적용안됨
	 * @return
	 * @throws Exception
	 */
	/*
	public static <T> T send(MciChannelConst channel,String soapId, Object inVo, Class<T> outClass) throws Exception {
		return send(channel, soapId, inVo, outClass, 0);
	}
	*/
	/*
	public static <T> T send(MciChannelConst channel,String soapId, Object inVo, Class<T> outClass, int timeoutMs) throws Exception {
		T outData = null;		
		String chUrl = "";
		
//		if (channel == MciChannelConst.LOCAL) {
//			chUrl = CcFwUtil.propUtil_getMessage("COMM_SOAP1_BASE_URL");	// TODO: 정상동작 확인되면 PropUtil.getMessage 로 바꿀 것
//		} else {
			// TODO : 관리자페이지 - 채널/전문 차단여부 체크
			String type = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_TYPE");			
			if (!"SOAP".equalsIgnoreCase(type)) {
				throw new Exception(channel.name()+" 처리할 수 없는 타입["+type+"]");
			}
			chUrl = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_BASE_URL");
//		}

		// 전문 Logging - 요청전문
		MciDBLogVo logVo = null;
		if (MciDBLog.isEnabled(soapId)) {
			logVo = MciDBLog.getLogVo(channel.name(), "SOAP", chUrl, soapId, timeoutMs, toJsonString(inVo));
		}
		try {
			// CcOlSoapClient클래스의 soapId method 호출
			try {
				Method toMethod = CcOlSoapClient.class.getMethod(soapId, new Class[] { String.class, inVo.getClass()});
				outData = (T)toMethod.invoke(null, new Object[] { chUrl, inVo});
			} catch (NoSuchMethodException e) {
				throw new Exception("구현되지 않거나 파라메터 클래스가 일치하지 않은 MCI 호출임 ["+channel.name()+","+soapId+"]");
			} catch (InvocationTargetException e) {
				if (e.getCause() != null) {
					throw (Exception)e.getCause();
				} else {
					throw e;
				}			
			}
			// 전문 Logging - 성공시
			MciDBLog.write(logVo, toJsonString(outData), null);
			logVo = null;
		} catch(NullPointerException e){	// sparrow
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, "", e);
			}
			throw e;
		} catch(Exception e){
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, "", e);
			}
			throw e;
		}
		
		if(AppLog.isDebugEnabled()) {
			// 결과 출력
			AppLog.debug("res Vo: " + toJsonString(outData));
		}
				
		return outData;
	}	*/

	/**
	 * MCI채널에 전문 송신하고 응답받기(NL용) 공통함수
	 * @param channel
	 * @param inVo
	 * @param outClass
	 * @param timeoutMs	시간제한 0보다 크면 적용됨
	 * @return
	 * @throws Exception
	 */
	public static <T> T send(MciChannelConst channel, CommVO inVo, Class<T> outClass) throws Exception {
		return send(channel, inVo, outClass, 0);
	}

	public static <T> T send(MciChannelConst channel, CommVO inVo, Class<T> outClass, int timeoutMs) throws Exception {
		// TODO : 관리자페이지 - 채널/전문 차단여부 체크
		String chType = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_TYPE").toUpperCase();
		switch(chType) {
			case "JSON":	// 대내 MCI용 JSON 방식
				return sendJSON(channel, inVo, outClass, timeoutMs);
			case "HFLD":	// 대외 MCI용 https + FLD 방식 (2021-08-03 추가)
				return sendHFLD(channel, inVo, outClass, timeoutMs);
			default:
				throw new Exception(channel.name()+" NL MCI에서 처리가능한 타입이 아님("+chType+")");
		}
	}

	// MCI채널에 전문 송신하고 응답받기(NL용) - JSON 타입 처리용으로 , http body에 JSON String을 전송하는 프로토콜, 대내 MCI 전문 호출에 사용
	private static <T> T sendJSON(MciChannelConst channel, CommVO inVo, Class<T> outClass, int timeoutMs) throws Exception {
		String chUrl = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_BASE_URL");

//		if (ElConfig.isLocalDevMode()) {
//			chUrl = "http://localhost:8080/nlJsonRecv.do";
//		}

		// 공통헤더 얻기
		MciCommHeaderVo tgrmCmnnhddvValu = _invokeGetter(inVo,"getTgrmCmnnhddvValu", MciCommHeaderVo.class);
				
		// CcFwUtil.initializeMembers(inVo, true);

		// validation
		if (tgrmCmnnhddvValu == null) throw new Exception("NL MCI전문 공통헤더 설정안됨");
		
		String itrfId = tgrmCmnnhddvValu.getItrfId();
		if (itrfId == null || itrfId.length() < 1) throw new Exception("NL MCI전문 공통헤더에 인터페이스ID(itrfId) 설정안됨");
		
		// 공통헤더에 자동세팅 가능한 부분 처리
		ElHeader elHeader = CcContextUtil.getElHeader();
		
		String glbId = tgrmCmnnhddvValu.getGlbId();
		if (glbId == null || glbId.length() < 1) {
			String appliDutjCd = itrfId.substring(0, 3); // 어플리케이션업무코드(3)
			tgrmCmnnhddvValu.setGlbId(_nextNlGlbId(appliDutjCd));
			// v1.03: 어플리케이션업무코드 - 글로벌ID에 포함되어 있지만 업무팀에서 별도사용이 용이하도록 명시적으로 분리 추가
			tgrmCmnnhddvValu.setAppliDutjCd(appliDutjCd);
		}
		
		// v1.05: 어플리케이션상세업무코드 - 고객채널 업무상세구분코드 3째자리 일련번호 규칙 : 앱(0), PC(1), 모바일웹(2)
		/*			홈페이지(PC)		DH1
					홈페이지(모바일웹)	DH2
					디지털창구(PC)		DA1
					디지털창구(모바일웹)	DA2
					디지털보험(PC)		DI1
					디지털보험(모바일웹)	DI2
					디지털플랫폼앱		DA0
		*/
		String appliDtptDutjCd = tgrmCmnnhddvValu.getAppliDtptDutjCd();
		if (appliDtptDutjCd == null || appliDtptDutjCd.length() < 3) {
			throw new Exception("NL MCI전문 공통헤더의 어플리케이션상세업무코드(appliDtptDutjCd)는 필수 컬럼입니다.");
		}

		// v1.03: 진행일련번호 - 글로벌ID에서 분리됨, 없으면 001 세팅
		String pgrsSriaNo = tgrmCmnnhddvValu.getPgrsSriaNo();
		if (pgrsSriaNo == null || pgrsSriaNo.length() < 1) {
			tgrmCmnnhddvValu.setPgrsSriaNo("001");
		}
		
		String inqrTraTypeCd = tgrmCmnnhddvValu.getInqrTraTypeCd();
		if (inqrTraTypeCd == null || inqrTraTypeCd.length() < 1) {
			// 조회거래유형코드 등록(C), 조회(R), 변경(U), 삭제(D), 인쇄(P), 다운로드(E) )
			throw new Exception("NL MCI전문 공통헤더의 조회거래유형코드(inqrTraTypeCd)는 필수 컬럼입니다.");
		}
		
		String envrTypeCd = tgrmCmnnhddvValu.getEnvrTypeCd();
		if (envrTypeCd == null || envrTypeCd.length() == 0) {
			envrTypeCd = ElConfig.getServerMode().substring(0, 1); // R:REAL(RUN), T:TEST(TST), D: 개발(DEV)
			if ("R".equals(envrTypeCd)) {
				envrTypeCd = "P";		// 20211126 (이준호C) 최초에는 'R'로 가이드 받았는데 최신 버전 보니 'P' 로 변경
			}
			tgrmCmnnhddvValu.setEnvrTypeCd(envrTypeCd);
		}
//		if (channel == MciChannelConst.NL_CDP && "D".equals(envrTypeCd)) {
//			// 20210824 이쪽 개발에서 NL_CDP 쪽 테스트로 연결되므로 변경해줌	- 20210915  설정을 DEV-URL로 원복하고 다른방식으로 처리
//			tgrmCmnnhddvValu.setEnvrTypeCd("T");
//		}	
		//if  ("D".equals(envrTypeCd)) {
		//	// 20211015 수신시스템이 OL FC영업지원인 경우 개발계로 전송 - 20211026 테스트/운영에서도 적용되는 로직이라 개발일때만 처리하도록 변경함
		//	if (tgrmCmnnhddvValu.getRcvSvcId() != null && tgrmCmnnhddvValu.getRcvSvcId().startsWith("AMRIFSM") ) {
		//		chUrl = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_BASE_URL");
		//		tgrmCmnnhddvValu.setEnvrTypeCd("D");
        //
		//	// 20210915 로컬설정에 홈페이지개발자로 설정된경우 개발은 개발로 정상 url 설정, 아니면 개발이어도 테스트url로 호출
		//	} else if (channel == MciChannelConst.NL_CDP) {
		//		// 홈페이지 개발자가아닌경우만 개발일때 테스트쪽으로 호출
		//		if (!"Y".equals(PropUtil.getMessage("NL_CDP_DEV_USE_DEVURL"))) {
		//			ElSysPropManager elspm = ElSysPropManager.getInstance();
		//			chUrl = elspm.getPropVoValue("MCI_PROP", channel.name()+"_BASE_URL.TST"); 
		//			tgrmCmnnhddvValu.setEnvrTypeCd("T");
		//		}
		//	}
		//} ### >> 20211123 이준호 처리계 테스트DB 이행으로 개발계MCI 통신 변경 비활성화
		
		if  ("T".equals(envrTypeCd)) {
			// 20211015 수신시스템이 OL FC영업지원인 경우 개발계로 전송
			if (tgrmCmnnhddvValu.getRcvSvcId() != null && tgrmCmnnhddvValu.getRcvSvcId().startsWith("AMRIFSM") ) {
				chUrl = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_BASE_URL");
				tgrmCmnnhddvValu.setEnvrTypeCd("D");
			}
		}
		
		tgrmCmnnhddvValu.setReqTgrmTnsmDtptDt(DateUtil.getNow("yyyyMMddHHmmssSSS"));
		tgrmCmnnhddvValu.setUserIpAddr(elHeader.getClientIp());
		
		// 디지털창구에서는 전문해더에 로그인 사용자가 아니라 정해진 사용자 정보를 입력함
		if(DpStringUtil.isEmpty(tgrmCmnnhddvValu.getUserId())) {
			tgrmCmnnhddvValu.setUserId(elHeader.getUserId());
		}
		
		// 요청파라메터로 변경
	    String paramStr = toJsonString(inVo);//.replace("&quot;", "\\\"");

		// TODO : 전문 Logging - 요청전문
		AppLog.debug("MciReq: " + channel+":"+paramStr);

	    // http로 서비스 호출
	    chUrl = chUrl.replace("{0}", itrfId); // ifId
		AppLog.debug("chUrl:["+chUrl+"]");

		MciDBLogVo logVo = null;
		if (MciDBLog.isEnabled(itrfId, inqrTraTypeCd)) {
			logVo = MciDBLog.getLogVo(channel.name(), "JSON", chUrl, itrfId, timeoutMs, paramStr);
		}
		
		String bbStr = "";
		try {
			byte[] bb = CcFwUtil.sendPostUrl(chUrl, paramStr.getBytes(ElConfig.getReqResEncode()), timeoutMs);
			bbStr = new String(bb,ElConfig.getReqResEncode());

			T outData;
			try {
				 outData = CcFwUtil.fromJsonString(bbStr, outClass);
			} catch(JsonParseException ee) {
				AppLog.debug("Error",ee);
				throw new JsonParseException("응답형식이 json이 아님", null);
			}

			Exception ue = null;
			try {
				// 공통헤더 얻기
				MciCommHeaderVo outHeader = _invokeGetter(outData,"getTgrmCmnnhddvValu", MciCommHeaderVo.class);
				
				if (!"0".equals(outHeader.getTgrmDalRsltCd())) {
					ue = new Exception("오류수신:"+outHeader.getTgrmDalRsltCd());
				} 
			} catch(NullPointerException ee) {	// sparrow
				AppLog.debug("BeIgnore",ee);
			} catch(Exception ee) {
				AppLog.debug("BeIgnore",ee);
			}
			if(AppLog.isDebugEnabled()) {
				AppLog.debug("MciRes: " + channel+":"+bbStr);
			}		
		
			// 전문 Logging - 성공시
			MciDBLog.write(logVo, bbStr, ue);
			logVo = null;
			
			return outData;
		} catch(NullPointerException e){ // sparrow
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, bbStr, e);
			}
			throw e;
		} catch(Exception e){
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, bbStr, e);
			}
			throw e;
		}
	}

	// MCI채널에 전문 송신하고 응답받기(NL용) - HFLD 타입 처리용으로 , http body에 FLD String을 전송하는 프로토콜, 20210803 대외 MCI 전문 호출에 사용하기위해 추가함
	private static <T> T sendHFLD(MciChannelConst channel, CommVO inVo, Class<T> outClass, int timeoutMs) throws Exception {
		// inVo/outVo 모두 FLD여부 Y 여야 하며 컬럼 구조는 다음과 같아야 함
		// tgrmCmnnhddvValu	MciCommHeaderVo
		// tgrmMsdvValu		MciCmouMsgVo
		// 이하 데이터컬럼들 또는 대내MCI Vo와 동일한 구조로 tgrmDtdvValu에 해당하는 Vo에 데이터컬럼들을 넣어야 함(FLD여부는 Y여야함)

		String chUrl = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_BASE_URL");

//		if (ElConfig.isLocalDevMode()) {
//			chUrl = "http://localhost:8080/nlHfldRecv.do";
//		}
		
		// 대외 MCI 전용 파라메터 추가
		String frbuCd = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_FRBU_CD");		// 대외기관코드
		String cmouDutjCd = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_CMOU_DUTJ_CD");	// 대외업무코드
		String chEnc = CcFwUtil.getElProp("MCI_PROP", channel.name()+"_ENCODE", "EUC-KR");	// FLD 인코딩 - 디폴트는 EUC-KR

		if (frbuCd.length() < 1) {
			throw new Exception("대외 MCI 프로퍼티의 대외기관코드("+channel.name()+"_FRBU_CD)는 반드시 설정되어있어야 합니다.");
		}
		if (cmouDutjCd.length() < 1) {
			throw new Exception("대외 MCI 프로퍼티의 대외업무코드("+channel.name()+"_CMOU_DUTJ_CD)는 반드시 설정되어있어야 합니다.");
		}

		// inVo/outVo 모두 FLD여부 Y 여야 하며 컬럼 구조는 다음과 같아야 함
		// tgrmCmnnhddvValu	MciCommHeaderVo
		// tgrmMsdvValu		MciCmouMsgVo
		// 이하 데이터컬럼들 또는 대내MCI Vo와 동일한 구조로 tgrmDtdvValu에 해당하는 Vo에 데이터컬럼들을 넣어야 함(FLD여부는 Y여야함)

		// 공통헤더 얻기
		MciCommHeaderVo tgrmCmnnhddvValu = _invokeGetter(inVo,"getTgrmCmnnhddvValu", MciCommHeaderVo.class);
				
		// CcFwUtil.initializeMembers(inVo, true);

		// validation
		if (tgrmCmnnhddvValu == null) throw new Exception("대외 MCI전문 공통헤더 설정안됨");
		
		String itrfId = tgrmCmnnhddvValu.getItrfId();
		if (itrfId == null || itrfId.length() < 1) throw new Exception("NL MCI전문 공통헤더에 인터페이스ID(itrfId) 설정안됨");
		
		// 공통헤더에 자동세팅 가능한 부분 처리
		ElHeader elHeader = CcContextUtil.getElHeader();
		
		String glbId = tgrmCmnnhddvValu.getGlbId();
		if (glbId == null || glbId.length() < 1) {
			String appliDutjCd = itrfId.substring(0, 3); // 어플리케이션업무코드(3)
			tgrmCmnnhddvValu.setGlbId(MciUtil._nextNlGlbId(appliDutjCd));		// Mci 대내 전문과 중복되지않도록 MciUtil 글로벌ID를 공유함 !!!!
			// v1.03: 어플리케이션업무코드 - 글로벌ID에 포함되어 있지만 업무팀에서 별도사용이 용이하도록 명시적으로 분리 추가
			tgrmCmnnhddvValu.setAppliDutjCd(appliDutjCd);
		}
		
		// v1.05: 어플리케이션상세업무코드 - 고객채널 업무상세구분코드 3째자리 일련번호 규칙 : 앱(0), PC(1), 모바일웹(2)
		/*			홈페이지(PC)		DH1
					홈페이지(모바일웹)	DH2
					디지털창구(PC)		DA1
					디지털창구(모바일웹)	DA2
					디지털보험(PC)		DI1
					디지털보험(모바일웹)	DI2
					디지털플랫폼앱		DA0
		*/
		String appliDtptDutjCd = tgrmCmnnhddvValu.getAppliDtptDutjCd();
		if (appliDtptDutjCd == null || appliDtptDutjCd.length() < 3) {
			throw new Exception("NL MCI전문 공통헤더의 어플리케이션상세업무코드(appliDtptDutjCd)는 필수 컬럼입니다.");
		}

		// v1.03: 진행일련번호 - 글로벌ID에서 분리됨, 없으면 001 세팅
		String pgrsSriaNo = tgrmCmnnhddvValu.getPgrsSriaNo();
		if (pgrsSriaNo == null || pgrsSriaNo.length() < 1) {
			tgrmCmnnhddvValu.setPgrsSriaNo("001");
		}
		
		String inqrTraTypeCd = tgrmCmnnhddvValu.getInqrTraTypeCd();
		if (inqrTraTypeCd == null || inqrTraTypeCd.length() < 1) {
			// 조회거래유형코드 등록(C), 조회(R), 변경(U), 삭제(D), 인쇄(P), 다운로드(E) )
			throw new Exception("NL MCI전문 공통헤더의 조회거래유형코드(inqrTraTypeCd)는 필수 컬럼입니다.");
		}
		
		String envrTypeCd = tgrmCmnnhddvValu.getEnvrTypeCd();
		if (envrTypeCd == null || envrTypeCd.length() == 0) {
			envrTypeCd = ElConfig.getServerMode().substring(0, 1); // R:REAL(RUN), T:TEST(TST), D: 개발(DEV)
			if ("R".equals(envrTypeCd)) {
				envrTypeCd = "P";		// 20211126 (이준호C) 최초에는 'R'로 가이드 받았는데 최신 버전 보니 'P' 로 변경
			}
			tgrmCmnnhddvValu.setEnvrTypeCd(envrTypeCd);
		}
		tgrmCmnnhddvValu.setReqTgrmTnsmDtptDt(DateUtil.getNow("yyyyMMddHHmmssSSS"));
		tgrmCmnnhddvValu.setUserIpAddr(elHeader.getClientIp());
		tgrmCmnnhddvValu.setUserId(elHeader.getUserId());

		// 대외 MCI 전용 파라메터 세팅
		tgrmCmnnhddvValu.setFrbuCd(frbuCd);
		tgrmCmnnhddvValu.setCmouDutjCd(cmouDutjCd);
		
		// 공통메시지 얻기
		MciHfldMsgVo tgrmMsdvValu = _invokeGetter(inVo,"getTgrmMsdvValu", MciHfldMsgVo.class);

		// validation
		if (tgrmMsdvValu == null) throw new Exception("대외 MCI전문 공통메시지 설정안됨");

		tgrmMsdvValu.getMsgHddvValu().setMsgRpttCc(1);	// 건수 1로
		


		// 요청파라메터로 변경
	    byte[] inVoBytes = null;
	    
		Method marshalMethod = inVo.getClass().getMethod("marshalFld", String.class );
		inVoBytes = (byte[])marshalMethod.invoke(inVo, chEnc);
		
		String paramStr = new String(inVoBytes,chEnc);

		// TODO : 전문 Logging - 요청전문
		if(AppLog.isDebugEnabled()) {
			AppLog.debug("HFLD Req: " + channel+":"+ paramStr);
			AppLog.debug("HFLD Req: " + MciUtil.toJsonString(inVo));
		}
		
		MciDBLogVo logVo = null;
		if (MciDBLog.isEnabled(itrfId, inqrTraTypeCd)) {
			logVo = MciDBLog.getLogVo(channel.name(), "HFLD", chUrl, itrfId, timeoutMs, paramStr);
		}
		
	    // https로 서비스 호출
		String bbStr = "";
		try {
			byte[] bb = CcFwUtil.sendPostUrl(chUrl, inVoBytes, timeoutMs);
			bbStr = new String(bb,chEnc);
			
			// 응답객체 얻기
			T outData = outClass.newInstance();
			Exception ve = null;
			try {
				Method unmarshalMethod = outData.getClass().getMethod("unMarshalFld", byte[].class, String.class );
				unmarshalMethod.invoke(outData, bb, chEnc);
			} catch(NullPointerException ee) {	// sparrow
				ve = ee;
			} catch(Exception ee) {
				ve = ee;
			}
			if (ve != null) {
				// 공통메시지 까지는 수신한 경우 에러처리 안함(에러응답시 본문은 안오는 상태일 수 있음)
				MciHfldMsgVo oMsgHdr = _invokeGetter(outData,"getTgrmMsdvValu", MciHfldMsgVo.class);
				if (oMsgHdr.getOffset() == 0) {
					throw ve;
				}
			}

			Exception ue = null;
			try {
				// 공통헤더 얻기
				MciCommHeaderVo outHeader = _invokeGetter(outData,"getTgrmCmnnhddvValu", MciCommHeaderVo.class);
				if (!"0".equals(outHeader.getTgrmDalRsltCd())) {
					ue = new Exception("오류수신:"+outHeader.getTgrmDalRsltCd());
				} 
			} catch(NullPointerException ee) {	// sparrow
				AppLog.debug("BeIgnore",ee);
			} catch(Exception ee) {
				AppLog.debug("BeIgnore",ee);
			}

			if(AppLog.isDebugEnabled()) {
				AppLog.debug("HFLD Res: " + channel+":"+bbStr);
				AppLog.debug("HFLD Res: " + MciUtil.toJsonString(outData));
			}		
		
			// 전문 Logging - 성공시
			MciDBLog.write(logVo, bbStr, ue);
			logVo = null;
			
			return outData;
		} catch(NullPointerException e){ // sparrow
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, bbStr, e);
			}
			throw e;
		} catch(Exception e){
			// 전문 Logging - 실패시
			if (logVo != null) {
				MciDBLog.write(logVo, bbStr, e);
			}
			throw e;
		}
	}
	/**
	 * 내부용 : 반드시 getObjectMapper()를 사용할 것, 직접 사용 금지
	 */
	private static ElMappingJacksonObjectMapper mciObjectMapper = null;
	
	/**
	 * getObjectMapper 필요시 초기화후 ElMappingJacksonObjectMapper를 얻어냄
	 * @return
	 */
	private static synchronized ElMappingJacksonObjectMapper getMciMapper() {
		if (mciObjectMapper == null) {
			// super class들의 멤버변수를 json string만들 때 제외하기 위한 맵 생성
			HashMap map = new HashMap();
			StringBuilder sb = new StringBuilder("fixedLengthVo,offset,totalPageCount");
			for(String kv : sb.toString().split(",")) map.put(kv, kv);
			Class<?> superClass = CommCommVO.class;
			while(superClass != null) {
				for(Field field : superClass.getDeclaredFields()) {
					String kv = field.getName();
					if (!"scrnId".equals(kv) && map.put(kv, kv) == null) {
						sb.append(',').append(kv);
					}
				}
				superClass = superClass.getSuperclass();
			}
//			System.err.println("무시할Field > "+sb.toString());
//			System.err.println("비교할Field > sessionTokenKey,securityData,fixedLengthVo,listCount,offset,pageIndex,pageNum,pageSize,pageUnit,startRowIndex,totalCount,totalPageCount");
			mciObjectMapper = new ElMappingJacksonObjectMapper();
			mciObjectMapper.setExcludeNullYn("N");
			mciObjectMapper.setExcludeNames(map);			
			mciObjectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mciObjectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
			mciObjectMapper.setPropertyNamingStrategy(new DefaultPropertyNamingStrategy());
		}
		return mciObjectMapper;
	}

	/**
	 * toJson Object를 JsonString으로 변환, useBean이 true인 경우 bean을 사용하므로 excludeNames는 변환에서 제외됨
	 * @param obj
	 * @return
	 * @throws JsonProcessingException
	 */
	public static String toJsonString(Object obj) throws Exception {
		if (obj instanceof CommVO) {
			return getMciMapper().writeValueAsString(obj);
		}
		return CcFwUtil.toJsonString(obj);
	}

	// Q#
//	public static OlHeaderVo OlHeaderSetting(){
//		OlHeaderVo header = new OlHeaderVo();
//		header.setSysCd("CY");
//		header.setPrcsrBoCd("9120000002");
//		header.setPrcsrDeptCd("9120000002");
//		header.setPrcsrDvCd("4310313000");
//		header.setPrcsrUserNo("9900000008");
//		header.setPrcsrUserId("9900000008");
//		header.setPrcsrUppDeptCd("9120000002");
//		header.setMsgCnt(new BigDecimal("0"));
//		header.setScrGriCnt(new BigDecimal("0"));
//		header.setSvcRunNm(CcContextUtil.getElHeader().getTraceId());// "guid");
//		header.setStdate(DateUtil.getNow("yyyyMMdd"));// "yyyyMMdd");
//		
//		return header;
//	}


	private static String s_globalNo = null;
	
	/**
	 * 글로벌id_전문추적키
	 * 날짜(8) + 발생서버hostname(8) + 업무코드(2) + 일련번호(12)
	 * ex) 20180719shlcal21HF094128771879
	 * 위 예제 같은 경우에는 일련번호를 시분초+십만분초 인거 같네요
	 * @return
	 */
	private static synchronized String _nextGlobalNo(String applCd) throws Exception {
	    String hostname = CommUtil.getHostName();
    	if (hostname == null || hostname.length() < 1) {
    		hostname = "lcalhost";
    	}
	
		String next = DateUtil.getNow("yyyyMMdd") + hostname.substring(0, 8) + applCd.substring(0, 2) + DateUtil.getNow("HHmmssSSS");
		int seq = 1;
		if (s_globalNo != null && s_globalNo.startsWith(next)) {
			seq = TypeConversionUtil.parseToInt(next.substring(27)) + 1;
		}
		next += TypeConversionUtil.intToString(seq, 3);
		s_globalNo = next;
		
		return next;		
	}
	
	private static String s_nlGlbId = null;

	static synchronized String _nextNlGlbId(String appliDutjCd) throws Exception {
	    String hostname = CommUtil.getHostName();	
    	if (hostname == null || hostname.length() < 1) {
    		hostname = "localhost";
    	}

		StringBuilder sb = new StringBuilder();
		sb.append(DateUtil.getNow("yyyyMMddHHmmssSSS"));	// 17
		sb.append((hostname+"________").substring(0,9));	// 9
		sb.append((appliDutjCd+"___").substring(0,3));		// 3 어플리케이션 업무코드
//		sb.append(("00000001"));							// 8 전문채번번호
		String next = sb.toString();
		int seq = 1;
		if (s_nlGlbId != null && s_nlGlbId.startsWith(next)) {
			seq = TypeConversionUtil.parseToInt(s_nlGlbId.substring(29)) + 1;
		}
		next += TypeConversionUtil.intToString(seq, 8);
		s_nlGlbId = next;
		
		return next;
	}
		
	/**
	 * _validate	SL공통헤더 검증
	 * @param reqHeader
	 */
	/*
	private static void _validate(CcSlMciUserHeader reqHeader) throws Exception {
		String val;
		val = reqHeader.getApplCd();
		if (val == null || val.length() == 0) throw new Exception("업무코드 applCd 필수값 누락임");
		
		val = reqHeader.getGroupCoCd();
		if (val == null || val.length() == 0) throw new Exception("그룹사코드 groupCoCd 필수값 누락임");

		val = reqHeader.getCrudFlag();
		if (val == null || val.length() == 0) throw new Exception("조회거래구분 crudFlag 필수값 누락임");
	}*/
	
	/**
	 * _invokeGetter	inVo.getMethod를 호출하여 리턴 Object를 받아옴 
	 * @param inVo
	 * @param getMethod
	 * @param outClass
	 */
	private static <T> T _invokeGetter(Object inVo, String getMethod, Class<T> outClass) throws Exception {
		Exception re1 = null;
		T outVo = null;
		try {
			Method toMethod = inVo.getClass().getMethod(getMethod, new Class[0]);
			outVo = (T)toMethod.invoke(inVo, new Object[0]);
		} catch (NullPointerException e) {
			re1 = e;
		} catch (Exception e) {
			re1 = e;
		} 
		if (re1 != null) {	// sparrow
			if (re1.getCause() != null) {
				throw (Exception)re1.getCause();
			} else {
				throw re1;
			}			
		}
		return outVo;
	}	
}
